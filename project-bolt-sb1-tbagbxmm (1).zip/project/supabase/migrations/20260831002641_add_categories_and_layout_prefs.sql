/*
# Add metric categories and dashboard layout preferences

1. Purpose
   Support categorization/tagging of metrics and customizable dashboard layout.
   Each custom metric can optionally belong to a category.
   Users can create, edit, and delete custom categories with badge colors.

2. New Tables
   - metric_categories: user-defined categories for grouping metrics
     * id (uuid, primary key)
     * user_id (uuid, references auth.users, defaults to auth.uid())
     * name (text, not null)
     * color (text, not null, default emerald)
     * created_at (timestamptz)

3. Modified Tables
   - custom_metrics: add column category_id (uuid, nullable, references metric_categories)
   - profiles: add columns layout_mode (text default 'grid'), card_order (text[] default '{}'),
     hidden_cards (text[] default '{}')

4. Security
   - metric_categories has RLS enabled with owner-scoped CRUD (authenticated only)
   - category_id on custom_metrics is nullable so existing metrics are unaffected

5. Important Notes
   - All new columns are nullable or have defaults so existing data is preserved
   - card_order and hidden_cards store metric/card IDs as text arrays
   - layout_mode stores 'grid' or 'stack'
*/

CREATE TABLE IF NOT EXISTS metric_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  color text NOT NULL DEFAULT '#10b981',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE metric_categories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_categories" ON metric_categories;
CREATE POLICY "select_own_categories" ON metric_categories FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_categories" ON metric_categories;
CREATE POLICY "insert_own_categories" ON metric_categories FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_categories" ON metric_categories;
CREATE POLICY "update_own_categories" ON metric_categories FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_categories" ON metric_categories;
CREATE POLICY "delete_own_categories" ON metric_categories FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Add category_id to custom_metrics (nullable, no data loss)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'custom_metrics' AND column_name = 'category_id'
  ) THEN
    ALTER TABLE custom_metrics ADD COLUMN category_id uuid REFERENCES metric_categories(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Add dashboard layout prefs to profiles
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'layout_mode'
  ) THEN
    ALTER TABLE profiles ADD COLUMN layout_mode text NOT NULL DEFAULT 'grid';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'card_order'
  ) THEN
    ALTER TABLE profiles ADD COLUMN card_order text[] NOT NULL DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'hidden_cards'
  ) THEN
    ALTER TABLE profiles ADD COLUMN hidden_cards text[] NOT NULL DEFAULT '{}';
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_metric_categories_user ON metric_categories(user_id);
