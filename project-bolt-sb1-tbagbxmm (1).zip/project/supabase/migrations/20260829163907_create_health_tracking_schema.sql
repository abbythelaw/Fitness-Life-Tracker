/*
# Create health tracking schema

1. Purpose
   Multi-user health tracking app. Each authenticated user owns their data.
   Tables: profiles, daily_logs, workouts, custom_metrics, custom_metric_logs,
   fasting_sessions, habits, habit_logs.

2. New Tables
   - profiles: user display info (name, avatar color, height, daily targets)
   - daily_logs: daily weight, sleep, water, calories entries (one per user per date)
   - workouts: exercise sessions with type, duration, intensity, calories
   - custom_metrics: user-defined metrics (name, unit, target, type, color)
   - custom_metric_logs: values for custom metrics per date
   - fasting_sessions: fasting timer sessions with start/end/target
   - habits: user-defined habits with icon and color
   - habit_logs: per-date done/not-done for each habit

3. Security
   - All tables have RLS enabled.
   - All tables are owner-scoped via user_id = auth.uid().
   - 4 policies per table (SELECT, INSERT, UPDATE, DELETE) for authenticated role.
   - user_id columns default to auth.uid() so inserts omitting user_id succeed.
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT 'User',
  avatar_color text NOT NULL DEFAULT '#10b981',
  height numeric NOT NULL DEFAULT 175,
  target_calories integer NOT NULL DEFAULT 600,
  target_water integer NOT NULL DEFAULT 8,
  target_sleep numeric NOT NULL DEFAULT 8,
  target_weight numeric NOT NULL DEFAULT 72,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Daily logs table
CREATE TABLE IF NOT EXISTS daily_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date text NOT NULL,
  weight numeric,
  sleep_hours numeric,
  sleep_quality numeric,
  water numeric,
  calories numeric,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

ALTER TABLE daily_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_daily_logs" ON daily_logs;
CREATE POLICY "select_own_daily_logs" ON daily_logs FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_daily_logs" ON daily_logs;
CREATE POLICY "insert_own_daily_logs" ON daily_logs FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_daily_logs" ON daily_logs;
CREATE POLICY "update_own_daily_logs" ON daily_logs FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_daily_logs" ON daily_logs;
CREATE POLICY "delete_own_daily_logs" ON daily_logs FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Workouts table
CREATE TABLE IF NOT EXISTS workouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date text NOT NULL,
  type text NOT NULL,
  duration integer NOT NULL,
  intensity text NOT NULL DEFAULT 'Medium',
  calories integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE workouts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_workouts" ON workouts;
CREATE POLICY "select_own_workouts" ON workouts FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_workouts" ON workouts;
CREATE POLICY "insert_own_workouts" ON workouts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_workouts" ON workouts;
CREATE POLICY "update_own_workouts" ON workouts FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_workouts" ON workouts;
CREATE POLICY "delete_own_workouts" ON workouts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Custom metrics table
CREATE TABLE IF NOT EXISTS custom_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  unit text NOT NULL,
  target numeric NOT NULL DEFAULT 1,
  type text NOT NULL DEFAULT 'numeric',
  color text NOT NULL DEFAULT '#10b981',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE custom_metrics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_custom_metrics" ON custom_metrics;
CREATE POLICY "select_own_custom_metrics" ON custom_metrics FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_custom_metrics" ON custom_metrics;
CREATE POLICY "insert_own_custom_metrics" ON custom_metrics FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_custom_metrics" ON custom_metrics;
CREATE POLICY "update_own_custom_metrics" ON custom_metrics FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_custom_metrics" ON custom_metrics;
CREATE POLICY "delete_own_custom_metrics" ON custom_metrics FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Custom metric logs table
CREATE TABLE IF NOT EXISTS custom_metric_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  metric_id uuid REFERENCES custom_metrics(id) ON DELETE CASCADE,
  date text NOT NULL,
  value numeric NOT NULL DEFAULT 0,
  done boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, metric_id, date)
);

ALTER TABLE custom_metric_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_cm_logs" ON custom_metric_logs;
CREATE POLICY "select_own_cm_logs" ON custom_metric_logs FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_cm_logs" ON custom_metric_logs;
CREATE POLICY "insert_own_cm_logs" ON custom_metric_logs FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_cm_logs" ON custom_metric_logs;
CREATE POLICY "update_own_cm_logs" ON custom_metric_logs FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_cm_logs" ON custom_metric_logs;
CREATE POLICY "delete_own_cm_logs" ON custom_metric_logs FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Fasting sessions table
CREATE TABLE IF NOT EXISTS fasting_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  started_at bigint NOT NULL,
  ended_at bigint,
  expected_end bigint NOT NULL,
  target_hours integer NOT NULL,
  label text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fasting_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_fasting" ON fasting_sessions;
CREATE POLICY "select_own_fasting" ON fasting_sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_fasting" ON fasting_sessions;
CREATE POLICY "insert_own_fasting" ON fasting_sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_fasting" ON fasting_sessions;
CREATE POLICY "update_own_fasting" ON fasting_sessions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_fasting" ON fasting_sessions;
CREATE POLICY "delete_own_fasting" ON fasting_sessions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Habits table
CREATE TABLE IF NOT EXISTS habits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  icon text NOT NULL DEFAULT 'Check',
  color text NOT NULL DEFAULT '#10b981',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE habits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_habits" ON habits;
CREATE POLICY "select_own_habits" ON habits FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_habits" ON habits;
CREATE POLICY "insert_own_habits" ON habits FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_habits" ON habits;
CREATE POLICY "update_own_habits" ON habits FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_habits" ON habits;
CREATE POLICY "delete_own_habits" ON habits FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Habit logs table
CREATE TABLE IF NOT EXISTS habit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  habit_id uuid REFERENCES habits(id) ON DELETE CASCADE,
  date text NOT NULL,
  done boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, habit_id, date)
);

ALTER TABLE habit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_habit_logs" ON habit_logs;
CREATE POLICY "select_own_habit_logs" ON habit_logs FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_habit_logs" ON habit_logs;
CREATE POLICY "insert_own_habit_logs" ON habit_logs FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_habit_logs" ON habit_logs;
CREATE POLICY "update_own_habit_logs" ON habit_logs FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_habit_logs" ON habit_logs;
CREATE POLICY "delete_own_habit_logs" ON habit_logs FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_daily_logs_user_date ON daily_logs(user_id, date);
CREATE INDEX IF NOT EXISTS idx_workouts_user_date ON workouts(user_id, date);
CREATE INDEX IF NOT EXISTS idx_cm_logs_user_metric ON custom_metric_logs(user_id, metric_id);
CREATE INDEX IF NOT EXISTS idx_fasting_user ON fasting_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_habit_logs_user_habit ON habit_logs(user_id, habit_id);
CREATE INDEX IF NOT EXISTS idx_habits_user ON habits(user_id);
CREATE INDEX IF NOT EXISTS idx_custom_metrics_user ON custom_metrics(user_id);
CREATE INDEX IF NOT EXISTS idx_profiles_user ON profiles(user_id);
