import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { UserProfile, CustomMetric, CustomMetricLog, DailyLog, WorkoutEntry, FastingSession, Habit, MetricType, MetricCategory } from '@/types';
import { supabase } from '@/lib/supabase';
import { createGuestProfile } from '@/lib/mockData';

interface AuthSession {
  userId: string | null;
  isGuest: boolean;
}

interface AuthContextValue {
  user: UserProfile | null;
  session: AuthSession;
  loading: boolean;
  authError: string | null;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  signup: (name: string, email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  loginAsGuest: () => void;
  logout: () => void;
  updateUser: (updater: (u: UserProfile) => UserProfile) => void;
  retry: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const GUEST_KEY = 'fitdash_guest';

function getGuest(): UserProfile | null {
  try {
    const raw = localStorage.getItem(GUEST_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveGuest(guest: UserProfile): void {
  localStorage.setItem(GUEST_KEY, JSON.stringify(guest));
}

async function fetchUserProfile(userId: string): Promise<{ profile: UserProfile | null; error: string | null }> {
  try {
    const { data: profile, error: profileErr } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    if (profileErr) return { profile: null, error: profileErr.message };
    if (!profile) return { profile: null, error: 'Profile not found. Please sign up first.' };

    const { data: dailyLogsRaw, error: e1 } = await supabase.from('daily_logs').select('*').eq('user_id', userId);
    if (e1) return { profile: null, error: e1.message };

    const { data: workoutsRaw, error: e2 } = await supabase.from('workouts').select('*').eq('user_id', userId);
    if (e2) return { profile: null, error: e2.message };

    const { data: metricsRaw, error: e3 } = await supabase.from('custom_metrics').select('*').eq('user_id', userId);
    if (e3) return { profile: null, error: e3.message };

    const { data: cmLogsRaw, error: e4 } = await supabase.from('custom_metric_logs').select('*').eq('user_id', userId);
    if (e4) return { profile: null, error: e4.message };

    const { data: fastingRaw, error: e5 } = await supabase.from('fasting_sessions').select('*').eq('user_id', userId);
    if (e5) return { profile: null, error: e5.message };

    const { data: habitsRaw, error: e6 } = await supabase.from('habits').select('*').eq('user_id', userId);
    if (e6) return { profile: null, error: e6.message };

    const { data: habitLogsRaw, error: e7 } = await supabase.from('habit_logs').select('*').eq('user_id', userId);
    if (e7) return { profile: null, error: e7.message };

    const { data: categoriesRaw, error: e8 } = await supabase.from('metric_categories').select('*').eq('user_id', userId);
    if (e8) return { profile: null, error: e8.message };

    const dailyLogs: Record<string, DailyLog> = {};
    for (const dl of dailyLogsRaw || []) {
      dailyLogs[dl.date] = {
        date: dl.date,
        weight: dl.weight ?? undefined,
        sleepHours: dl.sleep_hours ?? undefined,
        sleepQuality: dl.sleep_quality ?? undefined,
        water: dl.water ?? undefined,
        calories: dl.calories ?? undefined,
      };
    }

    const workouts: WorkoutEntry[] = (workoutsRaw || []).map((w) => ({
      id: w.id,
      date: w.date,
      type: w.type,
      duration: w.duration,
      intensity: w.intensity,
      calories: w.calories,
    }));

    const customMetrics: CustomMetric[] = (metricsRaw || []).map((m) => ({
      id: m.id,
      name: m.name,
      unit: m.unit,
      target: m.target,
      type: m.type as MetricType,
      color: m.color,
      categoryId: m.category_id || null,
      createdAt: new Date(m.created_at).getTime(),
    }));

    const customMetricLogs: Record<string, CustomMetricLog[]> = {};
    for (const cml of cmLogsRaw || []) {
      if (!customMetricLogs[cml.metric_id]) customMetricLogs[cml.metric_id] = [];
      customMetricLogs[cml.metric_id].push({
        date: cml.date,
        value: cml.value,
        done: cml.done ?? undefined,
      });
    }

    const fastingSessions: FastingSession[] = (fastingRaw || []).map((f) => ({
      id: f.id,
      startedAt: f.started_at,
      endedAt: f.ended_at,
      expectedEnd: f.expected_end,
      targetHours: f.target_hours,
      label: f.label,
    }));

    const habits: Habit[] = (habitsRaw || []).map((h) => {
      const logs: Record<string, boolean> = {};
      for (const hl of (habitLogsRaw || []).filter((l) => l.habit_id === h.id)) {
        logs[hl.date] = hl.done;
      }
      return {
        id: h.id,
        name: h.name,
        icon: h.icon,
        color: h.color,
        createdAt: new Date(h.created_at).getTime(),
        logs,
      };
    });

    const categories: MetricCategory[] = (categoriesRaw || []).map((c) => ({
      id: c.id,
      name: c.name,
      color: c.color,
    }));

    return {
      profile: {
        id: profile.id,
        email: '',
        name: profile.name,
        passwordHash: '',
        avatarColor: profile.avatar_color,
        height: Number(profile.height),
        dailyTargets: {
          calories: profile.target_calories,
          water: profile.target_water,
          sleep: Number(profile.target_sleep),
          weight: Number(profile.target_weight),
        },
        customMetrics,
        dailyLogs,
        workouts,
        customMetricLogs,
        fastingSessions,
        habits,
        categories: categories.length > 0 ? categories : [
          { id: 'cat_mobility', name: 'Mobility', color: '#06b6d4' },
          { id: 'cat_exercise', name: 'Exercise Related', color: '#10b981' },
          { id: 'cat_health', name: 'Overall Health', color: '#a855f7' },
        ],
        dashboardPrefs: {
          layout: (profile.layout_mode as 'grid' | 'stack') || 'grid',
          cardOrder: profile.card_order || [],
          hiddenCards: profile.hidden_cards || [],
        },
        createdAt: new Date(profile.created_at).getTime(),
      },
      error: null,
    };
  } catch (err) {
    return { profile: null, error: err instanceof Error ? err.message : 'Unknown error' };
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AuthSession>({ userId: null, isGuest: false });
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const loadProfile = useCallback(async (userId: string, email: string) => {
    setLoading(true);
    setAuthError(null);
    const { profile, error } = await fetchUserProfile(userId);
    if (error) {
      setAuthError(error);
      setUser(null);
    } else if (profile) {
      profile.email = email;
      setUser(profile);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    const guest = getGuest();
    if (guest) {
      setSession({ userId: null, isGuest: true });
      setUser(guest);
      setLoading(false);
      return;
    }

    supabase.auth.getSession().then(({ data: { session: sbSession } }) => {
      if (sbSession?.user) {
        setSession({ userId: sbSession.user.id, isGuest: false });
        loadProfile(sbSession.user.id, sbSession.user.email || '');
      } else {
        setLoading(false);
      }
    });

    supabase.auth.onAuthStateChange((event, sbSession) => {
      (async () => {
        if (event === 'SIGNED_OUT') {
          setSession({ userId: null, isGuest: false });
          setUser(null);
          setAuthError(null);
          return;
        }
        if (sbSession?.user && (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED')) {
          setSession({ userId: sbSession.user.id, isGuest: false });
          await loadProfile(sbSession.user.id, sbSession.user.email || '');
        }
      })();
    });
  }, [loadProfile]);

  const login = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { ok: false, error: error.message };
    return { ok: true };
  }, []);

  const signup = useCallback(async (name: string, email: string, password: string) => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { ok: false, error: error.message };
    if (!data.user) return { ok: false, error: 'Failed to create account.' };

    localStorage.removeItem(GUEST_KEY);

    const colors = ['#10b981', '#06b6d4', '#a855f7', '#ec4899', '#f59e0b', '#8b5cf6'];
    const { error: profileError } = await supabase.from('profiles').insert({
      user_id: data.user.id,
      name,
      avatar_color: colors[Math.floor(Math.random() * colors.length)],
      height: 175,
      target_calories: 600,
      target_water: 8,
      target_sleep: 8,
      target_weight: 72,
    });
    if (profileError) return { ok: false, error: profileError.message };

    return { ok: true };
  }, []);

  const loginAsGuest = useCallback(() => {
    const existing = getGuest();
    const guest = existing || createGuestProfile();
    if (!existing) saveGuest(guest);
    setSession({ userId: null, isGuest: true });
    setUser(guest);
    setLoading(false);
    setAuthError(null);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(GUEST_KEY);
    supabase.auth.signOut();
    setSession({ userId: null, isGuest: false });
    setUser(null);
    setAuthError(null);
  }, []);

  const updateUser = useCallback((updater: (u: UserProfile) => UserProfile) => {
    setUser((prev) => {
      if (!prev) return prev;
      const updated = updater({ ...prev });
      if (session.isGuest) {
        saveGuest(updated);
      }
      return updated;
    });
  }, [session.isGuest]);

  const retry = useCallback(() => {
    if (session.userId) {
      loadProfile(session.userId, user?.email || '');
    }
  }, [session.userId, user?.email, loadProfile]);

  return (
    <AuthContext.Provider value={{ user, session, loading, authError, login, signup, loginAsGuest, logout, updateUser, retry }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
