export type MetricType = 'numeric' | 'scale' | 'duration' | 'boolean';

export type DashboardLayout = 'grid' | 'stack';

export interface MetricCategory {
  id: string;
  name: string;
  color: string;
}

export interface CustomMetric {
  id: string;
  name: string;
  unit: string;
  target: number;
  type: MetricType;
  color: string;
  categoryId: string | null;
  createdAt: number;
}

export interface DailyLog {
  date: string; // YYYY-MM-DD
  weight?: number;
  sleepHours?: number;
  sleepQuality?: number; // 1-10
  water?: number; // glasses
  calories?: number; // active calories burned
}

export interface WorkoutEntry {
  id: string;
  date: string;
  type: string;
  duration: number; // minutes
  intensity: 'Low' | 'Medium' | 'High';
  calories: number;
}

export interface CustomMetricLog {
  date: string;
  value: number;
  done?: boolean; // for boolean metrics
}

export interface Habit {
  id: string;
  name: string;
  icon: string; // lucide icon name
  color: string;
  createdAt: number;
  logs: Record<string, boolean>; // date -> done
}

export type FastingStage = 'fed' | 'early' | 'fatBurning' | 'ketosis' | 'autophagy';

export interface FastingSession {
  id: string;
  startedAt: number; // epoch ms
  endedAt: number | null; // null = in progress
  expectedEnd: number; // epoch ms
  targetHours: number;
  label: string;
}

export interface DashboardLayoutPrefs {
  layout: DashboardLayout;
  cardOrder: string[]; // metric/card IDs in display order
  hiddenCards: string[]; // metric/card IDs that are hidden
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  avatarColor: string;
  height: number; // cm
  dailyTargets: {
    calories: number;
    water: number;
    sleep: number;
    weight: number;
  };
  customMetrics: CustomMetric[];
  dailyLogs: Record<string, DailyLog>;
  workouts: WorkoutEntry[];
  customMetricLogs: Record<string, CustomMetricLog[]>; // metricId -> logs
  fastingSessions: FastingSession[];
  habits: Habit[];
  categories: MetricCategory[];
  dashboardPrefs: DashboardLayoutPrefs;
  createdAt: number;
}

export interface AuthSession {
  userId: string | null;
  isGuest: boolean;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}
