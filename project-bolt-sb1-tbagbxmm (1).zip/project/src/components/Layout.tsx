import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import type { ViewType } from '@/App';
import {
  Activity, LayoutDashboard, Dumbbell, Plus, Settings, LogOut,
  ChevronDown, Download, Ruler, Target, Flame, Timer, CheckCircle2, History,
} from 'lucide-react';
import { calcBMI, bmiStatus, getLatestLog, exportJSON, exportCSV } from '@/lib/data';

interface SidebarProps {
  view: ViewType;
  onViewChange: (v: ViewType) => void;
  onLogEntry: () => void;
  onLogWorkout: () => void;
  onAddMetric: () => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const NAV_ITEMS: { id: ViewType; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'workouts', label: 'Workouts', icon: Dumbbell },
  { id: 'habits', label: 'Habits', icon: CheckCircle2 },
  { id: 'fasting', label: 'Fasting', icon: Timer },
  { id: 'history', label: 'History', icon: History },
];

export function Sidebar({ view, onViewChange, onLogEntry, onLogWorkout, onAddMetric, collapsed, onToggleCollapse }: SidebarProps) {
  return (
    <aside
      className={`hidden lg:flex flex-col fixed left-0 top-0 h-screen glass-card rounded-none border-y-0 border-l-0 transition-all duration-300 ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      <div className="flex items-center gap-3 px-5 h-16 border-b border-ink-700/60">
        <div className="w-10 h-10 rounded-xl bg-neon-emerald/10 flex items-center justify-center neon-border-emerald shrink-0">
          <Activity size={22} className="text-neon-emerald" />
        </div>
        {!collapsed && <span className="text-lg font-extrabold text-slate-100">VitalTrack</span>}
      </div>

      <nav className="flex-1 px-3 py-5 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = view === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                active
                  ? 'bg-neon-emerald/10 text-neon-emerald neon-border-emerald'
                  : 'text-slate-400 hover:bg-ink-800 hover:text-slate-200'
              }`}
            >
              <Icon size={20} className="shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </button>
          );
        })}
      </nav>

      <div className="px-3 py-3 space-y-1 border-t border-ink-700/60">
        <button
          onClick={onLogEntry}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:bg-ink-800 transition ${
            collapsed ? 'justify-center' : ''
          }`}
        >
          <Plus size={20} className="shrink-0 text-neon-cyan" />
          {!collapsed && <span>Log Entry</span>}
        </button>
        <button
          onClick={onLogWorkout}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:bg-ink-800 transition ${
            collapsed ? 'justify-center' : ''
          }`}
        >
          <Dumbbell size={20} className="shrink-0 text-neon-purple" />
          {!collapsed && <span>Log Workout</span>}
        </button>
        <button
          onClick={onAddMetric}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:bg-ink-800 transition ${
            collapsed ? 'justify-center' : ''
          }`}
        >
          <Activity size={20} className="shrink-0 text-neon-emerald" />
          {!collapsed && <span>Add Metric</span>}
        </button>
      </div>

      <button
        onClick={onToggleCollapse}
        className="px-5 py-3 text-xs text-slate-500 hover:text-slate-300 transition flex items-center gap-2"
      >
        <Settings size={16} />
        {!collapsed && <span>Collapse</span>}
      </button>
    </aside>
  );
}

export function MobileNav({ view, onViewChange, onLogEntry }: { view: ViewType; onViewChange: (v: ViewType) => void; onLogEntry: () => void }) {
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 glass-card rounded-none border-x-0 border-b-0">
      <div className="flex items-center justify-around px-2 py-2">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = view === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`flex flex-col items-center gap-1 px-4 py-1.5 rounded-lg text-xs font-medium transition ${
                active ? 'text-neon-emerald' : 'text-slate-500'
              }`}
            >
              <Icon size={22} />
              {item.label}
            </button>
          );
        })}
        <button
          onClick={onLogEntry}
          className="flex flex-col items-center gap-1 px-4 py-1.5 rounded-lg text-xs font-medium text-neon-cyan"
        >
          <div className="w-10 h-10 -mt-5 rounded-full bg-neon-cyan/10 neon-border-emerald flex items-center justify-center" style={{ boxShadow: '0 0 0 1px rgba(6,182,212,0.3), 0 0 20px rgba(6,182,212,0.15)' }}>
            <Plus size={22} />
          </div>
          Log
        </button>
      </div>
    </div>
  );
}

export function TopBar({ onLogEntry, onLogWorkout, onAddMetric }: { onLogEntry: () => void; onLogWorkout: () => void; onAddMetric: () => void }) {
  const { user, session, logout, updateUser } = useAuth();
  const { showToast } = useToast();
  const [menuOpen, setMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
        setSettingsOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  if (!user) return null;

  const latest = getLatestLog(user);
  const weight = latest?.weight || 0;
  const bmi = calcBMI(weight, user.height);
  const status = bmiStatus(bmi);
  const initials = user.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();

  const handleExport = (fmt: 'json' | 'csv') => {
    if (fmt === 'json') exportJSON(user);
    else exportCSV(user);
    showToast(`Exported data as ${fmt.toUpperCase()}`);
    setMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 h-16 glass-card rounded-none border-x-0 border-t-0 flex items-center justify-between px-4 sm:px-6">
      <div className="flex items-center gap-3 lg:hidden">
        <div className="w-9 h-9 rounded-xl bg-neon-emerald/10 flex items-center justify-center neon-border-emerald">
          <Activity size={20} className="text-neon-emerald" />
        </div>
        <span className="font-extrabold text-slate-100">VitalTrack</span>
      </div>
      <div className="hidden lg:block">
        <p className="text-sm text-slate-400">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </p>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <div className="hidden sm:flex items-center gap-2">
          <button onClick={onLogEntry} className="btn-ghost text-xs px-3 py-2 hidden sm:flex items-center gap-1.5">
            <Plus size={14} /> Log
          </button>
          <button onClick={onLogWorkout} className="btn-ghost text-xs px-3 py-2 hidden md:flex items-center gap-1.5">
            <Dumbbell size={14} /> Workout
          </button>
          <button onClick={onAddMetric} className="btn-ghost text-xs px-3 py-2 hidden md:flex items-center gap-1.5">
            <Activity size={14} /> Metric
          </button>
        </div>

        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setMenuOpen((o) => !o)}
            className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-xl hover:bg-ink-800 transition"
          >
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-ink-950"
              style={{ backgroundColor: user.avatarColor }}
            >
              {initials}
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-sm font-semibold text-slate-100 leading-tight">{user.name}</p>
              <p className="text-xs text-slate-500 leading-tight">{session.isGuest ? 'Guest' : user.email}</p>
            </div>
            <ChevronDown size={16} className="text-slate-500" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-12 w-72 glass-card shadow-2xl animate-scale-in overflow-hidden">
              {!settingsOpen ? (
                <>
                  <div className="p-4 border-b border-ink-700/60">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center text-base font-bold text-ink-950"
                        style={{ backgroundColor: user.avatarColor }}
                      >
                        {initials}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-100">{user.name}</p>
                        <p className="text-xs text-slate-500">{session.isGuest ? 'Guest Mode' : user.email}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mt-4">
                      <div className="bg-ink-800 rounded-lg p-2 text-center">
                        <p className="text-xs text-slate-500">BMI</p>
                        <p className={`text-sm font-bold ${status.color}`}>{bmi || '--'}</p>
                      </div>
                      <div className="bg-ink-800 rounded-lg p-2 text-center">
                        <p className="text-xs text-slate-500">Weight</p>
                        <p className="text-sm font-bold text-slate-200">{weight || '--'}kg</p>
                      </div>
                      <div className="bg-ink-800 rounded-lg p-2 text-center">
                        <p className="text-xs text-slate-500">Height</p>
                        <p className="text-sm font-bold text-slate-200">{user.height}cm</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-2">
                    <button
                      onClick={() => setSettingsOpen(true)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-300 hover:bg-ink-800 transition"
                    >
                      <Settings size={18} /> Profile & Settings
                    </button>
                    <button
                      onClick={() => handleExport('json')}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-300 hover:bg-ink-800 transition"
                    >
                      <Download size={18} /> Export as JSON
                    </button>
                    <button
                      onClick={() => handleExport('csv')}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-300 hover:bg-ink-800 transition"
                    >
                      <Download size={18} /> Export as CSV
                    </button>
                  </div>
                  <div className="p-2 border-t border-ink-700/60">
                    <button
                      onClick={() => { logout(); showToast('Signed out successfully', 'info'); }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-red-400 hover:bg-red-500/10 transition"
                    >
                      <LogOut size={18} /> Log Out
                    </button>
                  </div>
                </>
              ) : (
                <SettingsPanel
                  onClose={() => setSettingsOpen(false)}
                  onSave={(height, targets) => {
                    updateUser((u) => {
                      u.height = height;
                      u.dailyTargets = targets;
                      return u;
                    });
                    showToast('Settings updated');
                    setSettingsOpen(false);
                  }}
                />
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

function SettingsPanel({ onClose, onSave }: { onClose: () => void; onSave: (height: number, targets: { calories: number; water: number; sleep: number; weight: number }) => void }) {
  const { user } = useAuth();
  const [height, setHeight] = useState(user?.height || 175);
  const [calories, setCalories] = useState(user?.dailyTargets.calories || 600);
  const [water, setWater] = useState(user?.dailyTargets.water || 8);
  const [sleep, setSleep] = useState(user?.dailyTargets.sleep || 8);
  const [weight, setWeight] = useState(user?.dailyTargets.weight || 72);

  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Settings size={18} className="text-neon-emerald" />
        <h3 className="font-semibold text-slate-100">Profile Settings</h3>
      </div>
      <div className="space-y-3">
        <div>
          <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 mb-1">
            <Ruler size={14} /> Height (cm)
          </label>
          <input type="number" value={height} onChange={(e) => setHeight(Number(e.target.value))} className="input-field" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 mb-1">
              <Flame size={14} /> Cal Target
            </label>
            <input type="number" value={calories} onChange={(e) => setCalories(Number(e.target.value))} className="input-field" />
          </div>
          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 mb-1">
              <Target size={14} /> Water Target
            </label>
            <input type="number" value={water} onChange={(e) => setWater(Number(e.target.value))} className="input-field" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-400 mb-1 block">Sleep Target (hrs)</label>
            <input type="number" step="0.5" value={sleep} onChange={(e) => setSleep(Number(e.target.value))} className="input-field" />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-400 mb-1 block">Weight Target (kg)</label>
            <input type="number" step="0.1" value={weight} onChange={(e) => setWeight(Number(e.target.value))} className="input-field" />
          </div>
        </div>
      </div>
      <div className="flex gap-2 mt-4">
        <button onClick={onClose} className="btn-ghost flex-1">Cancel</button>
        <button onClick={() => onSave(height, { calories, water, sleep, weight })} className="btn-primary flex-1">Save</button>
      </div>
    </div>
  );
}
