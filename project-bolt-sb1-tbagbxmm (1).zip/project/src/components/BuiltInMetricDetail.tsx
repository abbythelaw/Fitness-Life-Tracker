import { useState, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Modal } from '@/components/ui/Modal';
import { todayStr, upsertDailyLog, getCategoryName, getCategoryColor } from '@/lib/data';
import { isGuest, syncUpsertDailyLog, syncDeleteDailyLog } from '@/lib/sync';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
  LineChart, Line,
} from 'recharts';
import {
  TrendingUp, Flame, Target, ChevronLeft, ChevronRight, Pencil, Trash2, Check, X,
  Scale, Moon, Droplets, Flame as FlameIcon, BarChart3,
} from 'lucide-react';
import type { DailyLog, UserProfile } from '@/types';

export type BuiltInMetricId = 'weight' | 'calories' | 'sleep' | 'water' | 'bmi';

interface MetricConfig {
  id: BuiltInMetricId;
  label: string;
  unit: string;
  icon: React.ReactNode;
  color: string;
  target: number;
  logField: keyof DailyLog | null;
  hasQuality?: boolean;
}

type Range = 7 | 30 | 90 | 0; // 0 = all

const PAGE_SIZE = 8;

export function BuiltInMetricDetail({ metricId, onClose }: { metricId: BuiltInMetricId | null; onClose: () => void }) {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [range, setRange] = useState<Range>(30);
  const [page, setPage] = useState(0);
  const [editingDate, setEditingDate] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  if (!user || !metricId) return null;

  const config = getMetricConfig(user, metricId);
  if (!config) return null;

  const allLogs = useMemo(() => extractLogs(user, metricId), [user, metricId]);

  const filteredLogs = useMemo(() => {
    if (range === 0) return allLogs;
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - range);
    const cutoffStr = cutoff.toISOString().split('T')[0];
    return allLogs.filter((l) => l.date >= cutoffStr);
  }, [allLogs, range]);

  const chartData = filteredLogs.map((l) => ({
    date: new Date(l.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    value: l.value,
    ...(metricId === 'bmi' && { bmi: calcBMIFromLog(l.value, user.height) }),
  }));

  const sortedLogs = [...filteredLogs].sort((a, b) => b.date.localeCompare(a.date));
  const totalPages = Math.max(1, Math.ceil(sortedLogs.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages - 1);
  const pageLogs = sortedLogs.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);

  const latest = allLogs.length ? allLogs[allLogs.length - 1].value : 0;
  const avg = allLogs.length > 0 ? Math.round((allLogs.reduce((s, l) => s + l.value, 0) / allLogs.length) * 10) / 10 : 0;
  const max = allLogs.length > 0 ? Math.max(...allLogs.map((l) => l.value)) : 0;
  const target = config.target;
  const pct = target > 0 ? Math.round((latest / target) * 100) : 0;
  const remaining = Math.round((target - latest) * 10) / 10;

  const handleSaveEdit = (date: string) => {
    if (!config.logField) return;
    const val = Number(editValue);
    if (isNaN(val)) {
      showToast('Please enter a valid number', 'error');
      return;
    }
    updateUser((u) => {
      const existing = u.dailyLogs[date] || { date };
      (existing as Record<string, unknown>)[config.logField] = val;
      u.dailyLogs[date] = existing;
      if (!isGuest(u)) void syncUpsertDailyLog(u, existing);
      return u;
    });
    showToast('Log updated');
    setEditingDate(null);
    setEditValue('');
  };

  const handleDelete = (date: string) => {
    if (!config.logField) return;
    updateUser((u) => {
      const existing = u.dailyLogs[date];
      if (existing) {
        (existing as Record<string, unknown>)[config.logField] = undefined;
        u.dailyLogs[date] = existing;
        if (!isGuest(u)) void syncUpsertDailyLog(u, existing);
      }
      return u;
    });
    showToast('Log entry deleted', 'info');
  };

  return (
    <Modal open={!!metricId} onClose={onClose} title={config.label} subtitle={`${config.unit} · Target: ${target} ${config.unit}`} icon={config.icon}>
      <div className="space-y-5">
        {/* Range filter */}
        <div className="flex items-center gap-1 bg-ink-850 rounded-xl p-1 border border-ink-700 w-fit">
          {([7, 30, 90, 0] as Range[]).map((r) => (
            <button
              key={r}
              onClick={() => { setRange(r); setPage(0); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                range === r ? 'bg-neon-emerald/10 text-neon-emerald' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {r === 0 ? 'All Time' : `${r}d`}
            </button>
          ))}
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-4 gap-2">
          <div className="bg-ink-800 rounded-xl p-3 text-center">
            <p className="text-xl font-extrabold text-slate-100">{latest || '--'}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Latest</p>
          </div>
          <div className="bg-ink-800 rounded-xl p-3 text-center">
            <p className="text-xl font-extrabold text-slate-100">{avg || '--'}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Average</p>
          </div>
          <div className="bg-ink-800 rounded-xl p-3 text-center">
            <p className="text-xl font-extrabold text-slate-100">{max || '--'}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Best</p>
          </div>
          <div className="bg-ink-800 rounded-xl p-3 text-center">
            <p className="text-xl font-extrabold" style={{ color: config.color }}>{pct}%</p>
            <p className="text-[10px] text-slate-500 mt-0.5">To Target</p>
          </div>
        </div>

        {/* Progress to target */}
        <div className="bg-ink-800 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
              <Target size={14} /> Progress to Target
            </span>
            <span className="text-xs text-slate-500">
              {remaining > 0 ? `${remaining} ${config.unit} to go` : 'Target reached!'}
            </span>
          </div>
          <div className="h-3 bg-ink-700 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{
                width: `${Math.min(100, Math.max(0, pct))}%`,
                background: `linear-gradient(90deg, ${config.color}, ${config.color}cc)`,
              }}
            />
          </div>
          <div className="flex justify-between mt-1.5 text-[10px] text-slate-600">
            <span>0</span>
            <span style={{ color: config.color }}>Target: {target} {config.unit}</span>
          </div>
        </div>

        {/* Trend chart */}
        {chartData.length > 0 && (
          <div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <TrendingUp size={14} /> Trend
            </h4>
            <ResponsiveContainer width="100%" height={200}>
              {metricId === 'bmi' ? (
                <LineChart data={chartData} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis yAxisId="weight" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis yAxisId="bmi" orientation="right" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#0d1320', border: '1px solid #1b2740', borderRadius: 12, fontSize: 12 }} labelStyle={{ color: '#94a3b8' }} />
                  <Line yAxisId="weight" type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2.5} dot={{ r: 3, fill: '#10b981' }} name="Weight (kg)" />
                  <Line yAxisId="bmi" type="monotone" dataKey="bmi" stroke="#a855f7" strokeWidth={2.5} dot={{ r: 3, fill: '#a855f7' }} name="BMI" strokeDasharray="5 5" />
                </LineChart>
              ) : (
                <AreaChart data={chartData} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                  <defs>
                    <linearGradient id="biDetailGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={config.color} stopOpacity={0.4} />
                      <stop offset="95%" stopColor={config.color} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#0d1320', border: '1px solid #1b2740', borderRadius: 12, fontSize: 12 }} labelStyle={{ color: '#94a3b8' }} />
                  <ReferenceLine y={target} stroke={config.color} strokeDasharray="4 4" strokeOpacity={0.4} />
                  <Area type="monotone" dataKey="value" stroke={config.color} strokeWidth={2.5} fill="url(#biDetailGrad)" />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>
        )}

        {/* Paginated log table */}
        <div>
          <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
            Log History ({sortedLogs.length})
          </h4>
          {sortedLogs.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-6">No logs yet</p>
          ) : (
            <>
              <div className="space-y-1.5">
                {pageLogs.map((log) => (
                  <div key={log.date} className="flex items-center justify-between bg-ink-800/50 rounded-lg px-3 py-2.5 group">
                    <span className="text-xs text-slate-400">
                      {new Date(log.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                    </span>
                    {editingDate === log.date ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="input-field w-20 text-xs py-1"
                          autoFocus
                          step="0.1"
                        />
                        <button onClick={() => handleSaveEdit(log.date)} className="w-7 h-7 rounded-lg bg-neon-emerald/10 flex items-center justify-center text-neon-emerald hover:bg-neon-emerald/20 transition">
                          <Check size={14} />
                        </button>
                        <button onClick={() => { setEditingDate(null); setEditValue(''); }} className="w-7 h-7 rounded-lg bg-ink-700 flex items-center justify-center text-slate-400 hover:text-slate-200 transition">
                          <X size={14} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold" style={{ color: config.color }}>
                          {log.value} {config.unit}
                        </span>
                        {config.logField && (
                          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition">
                            <button
                              onClick={() => { setEditingDate(log.date); setEditValue(String(log.value)); }}
                              className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:text-neon-cyan hover:bg-cyan-500/10 transition"
                            >
                              <Pencil size={13} />
                            </button>
                            <button
                              onClick={() => handleDelete(log.date)}
                              className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-3">
                  <button
                    onClick={() => setPage((p) => Math.max(0, p - 1))}
                    disabled={currentPage === 0}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-200 hover:bg-ink-800 transition disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <span className="text-xs text-slate-500">
                    Page {currentPage + 1} of {totalPages}
                  </span>
                  <button
                    onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                    disabled={currentPage >= totalPages - 1}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-200 hover:bg-ink-800 transition disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </Modal>
  );
}

function getMetricConfig(user: UserProfile, id: BuiltInMetricId): MetricConfig | null {
  const t = user.dailyTargets;
  switch (id) {
    case 'weight':
      return { id, label: 'Current Weight', unit: 'kg', icon: <Scale size={20} className="text-neon-emerald" />, color: '#10b981', target: t.weight, logField: 'weight' };
    case 'calories':
      return { id, label: 'Active Calories', unit: 'kcal', icon: <FlameIcon size={20} className="text-neon-amber" />, color: '#f59e0b', target: t.calories, logField: 'calories' };
    case 'sleep':
      return { id, label: 'Sleep', unit: 'hrs', icon: <Moon size={20} className="text-neon-cyan" />, color: '#06b6d4', target: t.sleep, logField: 'sleepHours', hasQuality: true };
    case 'water':
      return { id, label: 'Water Intake', unit: 'glasses', icon: <Droplets size={20} className="text-blue-400" />, color: '#3b82f6', target: t.water, logField: 'water' };
    case 'bmi':
      return { id, label: 'BMI Index', unit: 'kg/m²', icon: <BarChart3 size={20} className="text-neon-purple" />, color: '#a855f7', target: 25, logField: 'weight' };
    default:
      return null;
  }
}

function extractLogs(user: UserProfile, metricId: BuiltInMetricId): { date: string; value: number }[] {
  const config = getMetricConfig(user, metricId);
  if (!config || !config.logField) return [];
  return Object.values(user.dailyLogs)
    .filter((log) => log[config.logField!] != null)
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((log) => ({ date: log.date, value: log[config.logField!] as number }));
}

function calcBMIFromLog(weight: number, heightCm: number): number {
  if (!heightCm || !weight) return 0;
  return Math.round((weight / Math.pow(heightCm / 100, 2)) * 10) / 10;
}
