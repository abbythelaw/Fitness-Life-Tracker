import { useState, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { addHabit, removeHabit, toggleHabit, calcHabitStreak, getHabitCompletionRate, todayStr } from '@/lib/data';
import { syncUpsertHabitLog, isGuest } from '@/lib/sync';
import type { Habit } from '@/types';
import { Modal } from '@/components/ui/Modal';
import {
  Check, Plus, Trash2, Flame, BookOpen, Footprints, Ban, Droplets,
  Dumbbell, Brain, Apple, Moon, Sun, Coffee, Heart, Pencil, ChevronLeft, ChevronRight,
  Calendar, Filter, type LucideIcon,
} from 'lucide-react';

const HABIT_ICONS: Record<string, LucideIcon> = {
  BookOpen, Footprints, Ban, Droplets, Dumbbell, Brain, Apple, Moon, Sun, Coffee, Heart, Pencil,
};

const HABIT_COLORS = ['#10b981', '#06b6d4', '#a855f7', '#ec4899', '#f59e0b', '#3b82f6', '#8b5cf6'];

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function dateStr(year: number, month: number, day: number): string {
  return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function HabitsView() {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [addOpen, setAddOpen] = useState(false);
  const [calMonth, setCalMonth] = useState(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() };
  });
  const [selectedHabitId, setSelectedHabitId] = useState<string | null>(null);
  const today = todayStr();

  if (!user) return null;

  const habits = user.habits || [];
  const selectedHabit = habits.find((h) => h.id === selectedHabitId) || null;

  const handleToggle = (habitId: string, date: string) => {
    updateUser((u) => {
      const habit = u.habits.find((h) => h.id === habitId);
      if (habit) {
        habit.logs[date] = !habit.logs[date];
        if (!isGuest(u)) void syncUpsertHabitLog(u, habitId, date, habit.logs[date]);
      }
      return u;
    });
  };

  const handleDelete = (habitId: string, name: string) => {
    updateUser((u) => removeHabit(u, habitId));
    if (selectedHabitId === habitId) setSelectedHabitId(null);
    showToast(`Removed "${name}" habit`, 'info');
  };

  // Calendar grid for current month
  const calendarDays = useMemo(() => {
    const { year, month } = calMonth;
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevMonthDays = new Date(year, month, 0).getDate();

    const cells: { date: string; day: number; inMonth: boolean; isToday: boolean; isFuture: boolean }[] = [];

    // Previous month trailing days
    for (let i = firstDay - 1; i >= 0; i--) {
      const day = prevMonthDays - i;
      const m = month === 0 ? 11 : month - 1;
      const y = month === 0 ? year - 1 : year;
      cells.push({ date: dateStr(y, m, day), day, inMonth: false, isToday: false, isFuture: false });
    }

    // Current month days
    for (let day = 1; day <= daysInMonth; day++) {
      const ds = dateStr(year, month, day);
      cells.push({
        date: ds,
        day,
        inMonth: true,
        isToday: ds === today,
        isFuture: ds > today,
      });
    }

    // Next month leading days to fill the grid
    const remaining = 42 - cells.length;
    for (let day = 1; day <= remaining; day++) {
      const m = month === 11 ? 0 : month + 1;
      const y = month === 11 ? year + 1 : year;
      cells.push({ date: dateStr(y, m, day), day, inMonth: false, isToday: false, isFuture: false });
    }

    return cells;
  }, [calMonth, today]);

  const monthLabel = new Date(calMonth.year, calMonth.month, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const prevMonth = () => {
    setCalMonth((prev) => {
      const m = prev.month === 0 ? 11 : prev.month - 1;
      const y = prev.month === 0 ? prev.year - 1 : prev.year;
      return { year: y, month: m };
    });
  };

  const nextMonth = () => {
    setCalMonth((prev) => {
      const m = prev.month === 11 ? 0 : prev.month + 1;
      const y = prev.month === 11 ? prev.year + 1 : prev.year;
      return { year: y, month: m };
    });
  };

  const goToToday = () => {
    const now = new Date();
    setCalMonth({ year: now.getFullYear(), month: now.getMonth() });
  };

  // Stats for the selected habit or all habits
  const doneTodayCount = habits.filter((h) => h.logs[today]).length;
  const bestStreak = Math.max(0, ...habits.map((h) => calcHabitStreak(h)));

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-100">Habit Tracker</h1>
          <p className="text-sm text-slate-400 mt-0.5">Build streaks, form lasting habits</p>
        </div>
        <button onClick={() => setAddOpen(true)} className="btn-primary text-xs flex items-center gap-1.5">
          <Plus size={14} /> New Habit
        </button>
      </div>

      {/* Summary stats */}
      {habits.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <div className="glass-card p-4 text-center">
            <p className="text-2xl font-extrabold text-slate-100">{habits.length}</p>
            <p className="text-xs text-slate-500">Active Habits</p>
          </div>
          <div className="glass-card p-4 text-center">
            <p className="text-2xl font-extrabold text-neon-emerald">{doneTodayCount}</p>
            <p className="text-xs text-slate-500">Done Today</p>
          </div>
          <div className="glass-card p-4 text-center">
            <p className="text-2xl font-extrabold text-neon-amber">{bestStreak}</p>
            <p className="text-xs text-slate-500">Best Streak</p>
          </div>
        </div>
      )}

      {habits.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Check size={40} className="mx-auto text-slate-600 mb-3" />
          <p className="text-slate-400 mb-1">No habits yet</p>
          <p className="text-sm text-slate-500">Tap "New Habit" to start building a routine</p>
        </div>
      ) : (
        <>
          {/* Habit filter chips */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mr-1">
              <Filter size={14} />
            </div>
            <button
              onClick={() => setSelectedHabitId(null)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                !selectedHabitId ? 'bg-neon-cyan/10 text-neon-cyan' : 'bg-ink-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              All Habits
            </button>
            {habits.map((habit) => {
              const Icon = HABIT_ICONS[habit.icon] || Check;
              const isActive = selectedHabitId === habit.id;
              return (
                <button
                  key={habit.id}
                  onClick={() => setSelectedHabitId(isActive ? null : habit.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
                    isActive ? '' : 'bg-ink-800 text-slate-400 hover:text-slate-200'
                  }`}
                  style={isActive ? { backgroundColor: `${habit.color}20`, color: habit.color } : {}}
                >
                  <Icon size={13} />
                  {habit.name}
                </button>
              );
            })}
          </div>

          {/* Calendar */}
          <div className="glass-card p-4 sm:p-6">
            {/* Calendar header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Calendar size={20} className="text-neon-cyan" />
                <h3 className="text-lg font-bold text-slate-100">{monthLabel}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={goToToday} className="btn-ghost text-xs px-2.5 py-1.5">Today</button>
                <button onClick={prevMonth} className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-200 hover:bg-ink-800 transition">
                  <ChevronLeft size={18} />
                </button>
                <button onClick={nextMonth} className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-200 hover:bg-ink-800 transition">
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>

            {/* Weekday labels */}
            <div className="grid grid-cols-7 gap-1.5 mb-1.5">
              {WEEKDAYS.map((wd) => (
                <div key={wd} className="text-center text-[10px] font-semibold text-slate-600 uppercase tracking-wide py-1">
                  {wd}
                </div>
              ))}
            </div>

            {/* Calendar grid */}
            <div className="grid grid-cols-7 gap-1.5">
              {calendarDays.map((cell, i) => {
                const dayHabits = selectedHabit
                  ? [selectedHabit]
                  : habits;
                const doneCount = dayHabits.filter((h) => h.logs[cell.date]).length;
                const totalCount = dayHabits.length;
                const allDone = totalCount > 0 && doneCount === totalCount;
                const someDone = doneCount > 0 && !allDone;

                return (
                  <button
                    key={i}
                    onClick={() => {
                      if (!cell.inMonth || cell.isFuture) return;
                      if (selectedHabit) {
                        handleToggle(selectedHabit.id, cell.date);
                      } else if (habits.length === 1) {
                        handleToggle(habits[0].id, cell.date);
                      }
                    }}
                    disabled={!cell.inMonth || cell.isFuture || (!selectedHabit && habits.length > 1)}
                    className={`relative aspect-square rounded-lg flex flex-col items-center justify-center transition-all group ${
                      !cell.inMonth
                        ? 'opacity-30 cursor-default'
                        : cell.isFuture
                        ? 'opacity-40 cursor-not-allowed'
                        : !selectedHabit && habits.length > 1
                        ? 'cursor-default'
                        : 'hover:scale-105 hover:ring-1 hover:ring-white/20 cursor-pointer'
                    } ${
                      cell.isToday
                        ? 'ring-1 ring-neon-cyan/50'
                        : ''
                    }`}
                    style={
                      cell.inMonth && allDone && selectedHabit
                        ? { backgroundColor: `${selectedHabit.color}30`, boxShadow: `inset 0 0 0 1px ${selectedHabit.color}60` }
                        : cell.inMonth && allDone
                        ? { backgroundColor: 'rgba(16,185,129,0.15)' }
                        : cell.inMonth && someDone && selectedHabit
                        ? { backgroundColor: `${selectedHabit.color}15` }
                        : cell.inMonth && someDone
                        ? { backgroundColor: 'rgba(16,185,129,0.08)' }
                        : {}
                    }
                  >
                    <span className={`text-xs font-medium ${
                      cell.isToday ? 'text-neon-cyan' : cell.inMonth ? 'text-slate-300' : 'text-slate-600'
                    }`}>
                      {cell.day}
                    </span>
                    {cell.inMonth && !cell.isFuture && (
                      <div className="flex gap-0.5 mt-0.5 flex-wrap justify-center max-w-[80%]">
                        {dayHabits.slice(0, 4).map((h) => (
                          <div
                            key={h.id}
                            className="w-1.5 h-1.5 rounded-full"
                            style={{
                              backgroundColor: h.logs[cell.date] ? h.color : 'transparent',
                              border: h.logs[cell.date] ? 'none' : `1px solid ${h.color}40`,
                            }}
                          />
                        ))}
                      </div>
                    )}
                    {cell.inMonth && allDone && (
                      <Check
                        size={10}
                        className="absolute top-1 right-1"
                        style={{ color: selectedHabit ? selectedHabit.color : '#10b981' }}
                      />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Calendar hint */}
            <div className="mt-4 flex items-center gap-4 flex-wrap text-xs text-slate-500">
              {selectedHabit ? (
                <span className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded" style={{ backgroundColor: `${selectedHabit.color}30` }} />
                  Click a day to toggle "{selectedHabit.name}"
                </span>
              ) : habits.length === 1 ? (
                <span className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded bg-emerald-500/15" />
                  Click a day to toggle
                </span>
              ) : (
                <span className="flex items-center gap-1.5">
                  <Filter size={12} />
                  Select a habit above to edit individual days
                </span>
              )}
              <div className="flex items-center gap-3 ml-auto">
                <span className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-neon-emerald" /> Done
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full border border-slate-600" /> Not done
                </span>
              </div>
            </div>
          </div>

          {/* Habit cards with streaks */}
          <div className="space-y-3">
            {habits.map((habit) => (
              <HabitCard
                key={habit.id}
                habit={habit}
                today={today}
                onToggle={() => handleToggle(habit.id, today)}
                onDelete={() => handleDelete(habit.id, habit.name)}
                onFocus={() => setSelectedHabitId(habit.id)}
                isSelected={selectedHabitId === habit.id}
              />
            ))}
          </div>
        </>
      )}

      <AddHabitModal open={addOpen} onClose={() => setAddOpen(false)} onSave={(h) => {
        updateUser((u) => addHabit(u, h));
        showToast(`Habit "${h.name}" created`);
        setAddOpen(false);
      }} />
    </div>
  );
}

function HabitCard({
  habit, today, onToggle, onDelete, onFocus, isSelected,
}: {
  habit: Habit;
  today: string;
  onToggle: () => void;
  onDelete: () => void;
  onFocus: () => void;
  isSelected: boolean;
}) {
  const streak = calcHabitStreak(habit);
  const completionRate = getHabitCompletionRate(habit, 30);
  const doneToday = habit.logs[today];

  const last7Days = useMemo(() => {
    const days: { date: string; done: boolean }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      days.push({ date: dateStr, done: !!habit.logs[dateStr] });
    }
    return days;
  }, [habit]);

  const Icon = HABIT_ICONS[habit.icon] || Check;

  return (
    <div
      className={`glass-card p-4 animate-slide-up group transition cursor-pointer ${
        isSelected ? 'border-neon-cyan/40' : 'hover:border-ink-600'
      }`}
      onClick={onFocus}
    >
      <div className="flex items-center gap-4">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
          className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all shrink-0 ${
            doneToday ? 'scale-105' : 'hover:scale-105'
          }`}
          style={{
            backgroundColor: doneToday ? habit.color : `${habit.color}15`,
            boxShadow: doneToday ? `0 0 15px ${habit.color}40` : 'none',
          }}
        >
          {doneToday ? (
            <Check size={24} className="text-ink-950" />
          ) : (
            <Icon size={22} style={{ color: habit.color }} />
          )}
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="font-semibold text-slate-100">{habit.name}</h4>
            {streak > 0 && (
              <span className="chip bg-amber-500/10 text-neon-amber">
                <Flame size={12} /> {streak} day{streak !== 1 ? 's' : ''}
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-0.5">30-day completion: {completionRate}%</p>
        </div>

        {/* Last 7 days mini view */}
        <div className="hidden sm:flex items-center gap-1">
          {last7Days.map((d, i) => (
            <div
              key={i}
              className="w-6 h-6 rounded-md flex items-center justify-center transition"
              style={{
                backgroundColor: d.done ? habit.color : 'rgba(255,255,255,0.04)',
              }}
              title={`${d.date}: ${d.done ? 'Done' : 'Not done'}`}
            >
              {d.done && <Check size={12} className="text-ink-950" />}
            </div>
          ))}
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          className="opacity-0 group-hover:opacity-100 w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition"
        >
          <Trash2 size={16} />
        </button>
      </div>
    </div>
  );
}

interface AddHabitModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (habit: { name: string; icon: string; color: string }) => void;
}

function AddHabitModal({ open, onClose, onSave }: AddHabitModalProps) {
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('Check');
  const [color, setColor] = useState(HABIT_COLORS[0]);

  // Reset form when modal opens
  useMemo(() => {
    if (open) {
      setName('');
      setIcon('Check');
      setColor(HABIT_COLORS[Math.floor(Math.random() * HABIT_COLORS.length)]);
    }
  }, [open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    onSave({ name, icon, color });
    setName('');
  };

  return (
    <Modal open={open} onClose={onClose} title="New Habit" subtitle="Start building a new routine" icon={<Plus size={20} />}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Habit Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Read 30 min, Morning Walk"
            className="input-field"
            required
            autoFocus
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Icon</label>
          <div className="flex flex-wrap gap-2">
            {Object.entries(HABIT_ICONS).map(([iconName, IconComp]) => (
              <button
                key={iconName}
                type="button"
                onClick={() => setIcon(iconName)}
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition border ${
                  icon === iconName ? 'border-neon-emerald/40 bg-neon-emerald/10' : 'border-ink-600 bg-ink-800 hover:bg-ink-750'
                }`}
              >
                <IconComp size={18} className={icon === iconName ? 'text-neon-emerald' : 'text-slate-400'} />
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Color</label>
          <div className="flex gap-2">
            {HABIT_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={`w-8 h-8 rounded-full transition ${color === c ? 'ring-2 ring-offset-2 ring-offset-ink-850' : ''}`}
                style={{ backgroundColor: c, boxShadow: color === c ? `0 0 0 2px ${c}` : 'none' }}
              />
            ))}
          </div>
        </div>
        <div className="flex gap-2 pt-2">
          <button type="button" onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button type="submit" className="btn-primary flex-1 flex items-center justify-center gap-2">
            <Plus size={16} /> Create Habit
          </button>
        </div>
      </form>
    </Modal>
  );
}
