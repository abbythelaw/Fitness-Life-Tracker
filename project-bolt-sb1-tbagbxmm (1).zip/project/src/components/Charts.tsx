import { useState, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, AreaChart, Area, ReferenceLine, Legend,
} from 'recharts';
import { getRecentLogs, calcBMI, getMetricLogs, calcStreak, removeCustomMetric } from '@/lib/data';
import { TrendingUp, BarChart3, Moon, Activity, Trash2, Flame, CheckCircle2, Pencil } from 'lucide-react';
import { useToast } from '@/context/ToastContext';
import { MetricCalendar } from '@/components/ui/MetricCalendar';

type Range = 7 | 30 | 90;

export function ChartsSection({ onMetricClick }: { onMetricClick: (metricId: string) => void }) {
  const [range, setRange] = useState<Range>(7);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <TrendingUp size={20} className="text-neon-emerald" /> Trends & Analytics
        </h2>
        <div className="flex items-center gap-1 bg-ink-850 rounded-xl p-1 border border-ink-700">
          {([7, 30, 90] as Range[]).map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                range === r ? 'bg-neon-emerald/10 text-neon-emerald' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {r} Days
            </button>
          ))}
        </div>
      </div>

      <WeightBMIChart range={range} />
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <ActivityChart range={range} />
        <SleepChart range={range} />
      </div>
      <CustomMetricCharts onMetricClick={onMetricClick} />
    </div>
  );
}

function ChartCard({ title, icon, children, action }: { title: string; icon: React.ReactNode; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="glass-card p-5 animate-slide-up">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-slate-100 flex items-center gap-2">{icon} {title}</h3>
        {action}
      </div>
      {children}
    </div>
  );
}

function formatDate(date: string, range: Range): string {
  const d = new Date(date);
  if (range <= 7) return d.toLocaleDateString('en-US', { weekday: 'short' });
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function WeightBMIChart({ range }: { range: Range }) {
  const { user } = useAuth();
  const data = useMemo(() => {
    if (!user) return [];
    return getRecentLogs(user, range).map((log) => ({
      date: formatDate(log.date, range),
      weight: log.weight,
      bmi: calcBMI(log.weight || 0, user.height),
    }));
  }, [user, range]);

  return (
    <ChartCard title="Weight & BMI Trend" icon={<TrendingUp size={18} className="text-neon-emerald" />}>
      <ResponsiveContainer width="100%" height={280}>
        <LineChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
          <XAxis dataKey="date" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis yAxisId="weight" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis yAxisId="bmi" orientation="right" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={{ background: '#0d1320', border: '1px solid #1b2740', borderRadius: 12, fontSize: 12 }}
            labelStyle={{ color: '#94a3b8' }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Line yAxisId="weight" type="monotone" dataKey="weight" stroke="#10b981" strokeWidth={2.5} dot={{ r: 3, fill: '#10b981' }} name="Weight (kg)" />
          <Line yAxisId="bmi" type="monotone" dataKey="bmi" stroke="#a855f7" strokeWidth={2.5} dot={{ r: 3, fill: '#a855f7' }} name="BMI" strokeDasharray="5 5" />
        </LineChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

function ActivityChart({ range }: { range: Range }) {
  const { user } = useAuth();
  const data = useMemo(() => {
    if (!user) return [];
    return getRecentLogs(user, range).map((log) => ({
      date: formatDate(log.date, range),
      calories: log.calories || 0,
      target: user.dailyTargets.calories,
    }));
  }, [user, range]);

  return (
    <ChartCard title="Activity Breakdown" icon={<BarChart3 size={18} className="text-neon-amber" />}>
      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
          <XAxis dataKey="date" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={{ background: '#0d1320', border: '1px solid #1b2740', borderRadius: 12, fontSize: 12 }}
            labelStyle={{ color: '#94a3b8' }}
            cursor={{ fill: 'rgba(255,255,255,0.03)' }}
          />
          <ReferenceLine y={user?.dailyTargets.calories} stroke="#f59e0b" strokeDasharray="4 4" label={{ value: 'Target', fill: '#f59e0b', fontSize: 10 }} />
          <Bar dataKey="calories" radius={[6, 6, 0, 0]} name="Calories Burned">
            {data.map((entry, i) => (
              <Cell key={i} fill={entry.calories >= entry.target ? '#10b981' : '#f59e0b'} fillOpacity={0.85} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

function SleepChart({ range }: { range: Range }) {
  const { user } = useAuth();
  const data = useMemo(() => {
    if (!user) return [];
    return getRecentLogs(user, range).map((log) => ({
      date: formatDate(log.date, range),
      hours: log.sleepHours || 0,
      quality: log.sleepQuality || 0,
    }));
  }, [user, range]);

  return (
    <ChartCard title="Sleep Tracking" icon={<Moon size={18} className="text-neon-cyan" />}>
      <ResponsiveContainer width="100%" height={240}>
        <AreaChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id="sleepGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
              <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="qualGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
          <XAxis dataKey="date" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis yAxisId="hours" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis yAxisId="quality" orientation="right" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={{ background: '#0d1320', border: '1px solid #1b2740', borderRadius: 12, fontSize: 12 }}
            labelStyle={{ color: '#94a3b8' }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Area yAxisId="hours" type="monotone" dataKey="hours" stroke="#06b6d4" strokeWidth={2.5} fill="url(#sleepGrad)" name="Sleep (hrs)" />
          <Area yAxisId="quality" type="monotone" dataKey="quality" stroke="#a855f7" strokeWidth={2.5} fill="url(#qualGrad)" name="Quality Score" />
        </AreaChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

function CustomMetricCharts({ onMetricClick }: { onMetricClick: (metricId: string) => void }) {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();

  if (!user || user.customMetrics.length === 0) return null;

  const handleDelete = (id: string, name: string) => {
    updateUser((u) => removeCustomMetric(u, id));
    showToast(`Removed "${name}" metric`, 'info');
  };

  return (
    <div>
      <h3 className="font-semibold text-slate-100 flex items-center gap-2 mb-3">
        <Activity size={18} className="text-neon-purple" /> Custom Metrics
      </h3>
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {user.customMetrics.map((metric) => {
          const logs = getMetricLogs(user, metric.id);
          const latestLog = logs.length ? logs[logs.length - 1] : null;
          const latestVal = latestLog?.value || 0;
          const streak = calcStreak(logs, metric.type);
          const pct = metric.target > 0 ? Math.round((latestVal / metric.target) * 100) : 0;
          const isBoolean = metric.type === 'boolean';
          const isDone = latestLog?.done || false;
          const data = logs.map((l) => ({
            date: new Date(l.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            value: l.value,
          }));
          return (
            <div key={metric.id} className="glass-card p-5 animate-slide-up group cursor-pointer hover:border-ink-600 transition" onClick={() => onMetricClick(metric.id)}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-semibold text-slate-100 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: metric.color }} />
                    {metric.name}
                  </h4>
                  <div className="flex items-center gap-2 mt-1">
                    {isBoolean ? (
                      <span className={`chip ${isDone ? 'bg-emerald-500/10 text-neon-emerald' : 'bg-ink-700 text-slate-500'}`}>
                        {isDone ? <><CheckCircle2 size={12} /> Done today</> : 'Not done today'}
                      </span>
                    ) : (
                      <p className="text-xs text-slate-500">
                        Latest: <span className="font-semibold" style={{ color: metric.color }}>{latestVal} {metric.unit}</span>
                        {' · '}Target: {metric.target} {metric.unit} ({pct}%)
                      </p>
                    )}
                    {streak > 0 && (
                      <span className="chip bg-amber-500/10 text-neon-amber">
                        <Flame size={12} /> {streak} day{streak !== 1 ? 's' : ''}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <span className="opacity-0 group-hover:opacity-100 text-xs text-slate-500 transition">Click to view</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDelete(metric.id, metric.name); }}
                    className="opacity-0 group-hover:opacity-100 w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>

              {/* Calendar Heatmap */}
              <div className="mb-4">
                <MetricCalendar metric={metric} logs={logs} weeks={12} />
              </div>

              {/* Trend Chart (skip for boolean) */}
              {!isBoolean && data.length > 0 && (
                <ResponsiveContainer width="100%" height={140}>
                  <AreaChart data={data} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                    <defs>
                      <linearGradient id={`grad_${metric.id}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={metric.color} stopOpacity={0.4} />
                        <stop offset="95%" stopColor={metric.color} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="date" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ background: '#0d1320', border: '1px solid #1b2740', borderRadius: 12, fontSize: 12 }}
                      labelStyle={{ color: '#94a3b8' }}
                    />
                    <ReferenceLine y={metric.target} stroke={metric.color} strokeDasharray="4 4" strokeOpacity={0.4} />
                    <Area type="monotone" dataKey="value" stroke={metric.color} strokeWidth={2.5} fill={`url(#grad_${metric.id})`} />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
