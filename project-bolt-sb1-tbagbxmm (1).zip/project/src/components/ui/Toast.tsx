import { useToast } from '@/context/ToastContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export function ToastContainer() {
  const { toasts, dismissToast } = useToast();

  return (
    <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-[60] flex flex-col gap-2 w-[calc(100%-2rem)] sm:w-auto sm:min-w-[300px] sm:max-w-sm">
      {toasts.map((t) => {
        const Icon = t.type === 'success' ? CheckCircle2 : t.type === 'error' ? AlertCircle : Info;
        const color =
          t.type === 'success' ? 'text-neon-emerald' : t.type === 'error' ? 'text-red-400' : 'text-neon-cyan';
        const bg =
          t.type === 'success' ? 'bg-emerald-500/10' : t.type === 'error' ? 'bg-red-500/10' : 'bg-cyan-500/10';
        return (
          <div
            key={t.id}
            className={`glass-card ${bg} flex items-center gap-3 p-3.5 pr-3 animate-slide-up shadow-xl`}
          >
            <Icon size={20} className={color} />
            <p className="flex-1 text-sm text-slate-200">{t.message}</p>
            <button
              onClick={() => dismissToast(t.id)}
              className="text-slate-500 hover:text-slate-300 transition"
            >
              <X size={16} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
