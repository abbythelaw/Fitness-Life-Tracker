import { useMemo } from 'react';
import type { CustomMetricLog, CustomMetric } from '@/types';

interface MetricCalendarProps {
  metric: CustomMetric;
  logs: CustomMetricLog[];
  weeks?: number;
}

export function MetricCalendar({ metric, logs, weeks = 12 }: MetricCalendarProps) {
  const days = useMemo(() => {
    const result: { date: string; log?: CustomMetricLog; dayOfWeek: number }[] = [];
    const today = new Date();
    const totalDays = weeks * 7;
    for (let i = totalDays - 1; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const log = logs.find((l) => l.date === dateStr);
      result.push({ date: dateStr, log, dayOfWeek: d.getDay() });
    }
    return result;
  }, [logs, weeks]);

  const getIntensity = (log?: CustomMetricLog): number => {
    if (!log) return 0;
    if (metric.type === 'boolean') return log.done ? 1 : 0;
    if (metric.target > 0) return Math.min(1, log.value / metric.target);
    return log.value > 0 ? 0.5 : 0;
  };

  const getColor = (intensity: number): string => {
    if (intensity === 0) return 'rgba(255,255,255,0.04)';
    const alpha = metric.type === 'boolean' ? 0.9 : 0.25 + intensity * 0.65;
    const hex = metric.color;
    return hex + Math.round(alpha * 255).toString(16).padStart(2, '0');
  };

  const monthLabels = useMemo(() => {
    const labels: { label: string; index: number }[] = [];
    let lastMonth = -1;
    days.forEach((d, i) => {
      const m = new Date(d.date).getMonth();
      if (m !== lastMonth && i % 7 === 0) {
        labels.push({ label: new Date(d.date).toLocaleDateString('en-US', { month: 'short' }), index: i });
        lastMonth = m;
      }
    });
    return labels;
  }, [days]);

  return (
    <div className="overflow-x-auto">
      <div className="flex gap-1 mb-1 pl-7">
        {monthLabels.map((ml, i) => (
          <span key={i} className="text-[10px] text-slate-600 font-medium" style={{ position: 'absolute', left: `${ml.index * 14 + 28}px` }}>
            {ml.label}
          </span>
        ))}
      </div>
      <div className="flex gap-1">
        <div className="flex flex-col gap-1 justify-around py-0.5">
          {['Mon', 'Wed', 'Fri'].map((d) => (
            <span key={d} className="text-[10px] text-slate-600 w-6 text-right leading-[12px]">{d}</span>
          ))}
        </div>
        <div className="grid grid-flow-col grid-rows-7 gap-1">
          {days.map((d, i) => {
            const intensity = getIntensity(d.log);
            return (
              <div
                key={i}
                className="w-3 h-3 rounded-sm transition-all hover:scale-125 hover:ring-1 hover:ring-white/20 cursor-pointer"
                style={{ backgroundColor: getColor(intensity) }}
                title={`${d.date}: ${d.log ? (metric.type === 'boolean' ? (d.log.done ? 'Done' : 'Not done') : `${d.log.value} ${metric.unit}`) : 'No data'}`}
              />
            );
          })}
        </div>
      </div>
      <div className="flex items-center gap-2 mt-3 pl-7">
        <span className="text-[10px] text-slate-600">Less</span>
        {[0, 0.25, 0.5, 0.75, 1].map((i) => (
          <div key={i} className="w-3 h-3 rounded-sm" style={{ backgroundColor: getColor(i) }} />
        ))}
        <span className="text-[10px] text-slate-600">More</span>
      </div>
    </div>
  );
}
