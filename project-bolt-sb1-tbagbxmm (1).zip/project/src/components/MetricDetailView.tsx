import { useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { getMetricLogs, calcStreak } from '@/lib/data';
import { MetricCalendar } from '@/components/ui/MetricCalendar';
import { Modal } from '@/components/ui/Modal';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from 'recharts';
import { Flame, CheckCircle2, TrendingUp, Calendar, Pencil, Trash2 } from 'lucide-react';
import type { CustomMetric } from '@/types';

interface MetricDetailViewProps {
  metricId: string | null;
  onClose: () => void;
  onEdit: (metric: CustomMetric) => void;
  onDelete: (metric: CustomMetric) => void;
}

export function MetricDetailView({ metricId, onClose, onEdit, onDelete }: MetricDetailViewProps) {
  const { user } = useAuth();

  if (!user || !metricId) return null;
  const metric = user.customMetrics.find((m) => m.id === metricId);
  if (!metric) return null;

  const logs = getMetricLogs(user, metric.id);
  const streak = calcStreak(logs, metric.type);
  const isBoolean = metric.type === 'boolean';
  const latestLog = logs.length ? logs[logs.length - 1] : null;
  const latestVal = latestLog?.value || 0;
  const pct = metric.target > 0 ? Math.round((latestVal / metric.target) * 100) : 0;

  const avg = logs.length > 0 ? Math.round(logs.reduce((s, l) => s + l.value, 0) / logs.length) : 0;
  const max = logs.length > 0 ? Math.max(...logs.map((l) => l.value)) : 0;
  const doneCount = logs.filter((l) => l.done).length;

  const chartData = logs.map((l) => ({
    date: new Date(l.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    value: l.value,
  }));

  const sortedLogs = [...logs].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <Modal open={!!metricId} onClose={onClose} title={metric.name} subtitle={`${metric.type === 'boolean' ? 'Done / Not Done' : `${metric.unit} · Target: ${metric.target}`} `} icon={<span className="w-5 h-5 rounded-full inline-block" style={{ backgroundColor: metric.color }} />}>
      <div className="space-y-5">
        {/* Stats row */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-ink-800 rounded-xl p-3 text-center">
            {streak > 0 ? (
              <>
                <p className="text-2xl font-extrabold text-neon-amber flex items-center justify-center gap-1">
                  <Flame size={16} /> {streak}
                </p>
                <p className="text-xs text-slate-500 mt-0.5">Day streak</p>
              </>
            ) : (
              <>
                <p className="text-2xl font-extrabold text-slate-400">0</p>
                <p className="text-xs text-slate-500 mt-0.5">Day streak</p>
              </>
            )}
          </div>
          {isBoolean ? (
            <div className="bg-ink-800 rounded-xl p-3 text-center">
              <p className="text-2xl font-extrabold text-neon-emerald">{doneCount}</p>
              <p className="text-xs text-slate-500 mt-0.5">Days done</p>
            </div>
          ) : (
            <div className="bg-ink-800 rounded-xl p-3 text-center">
              <p className="text-2xl font-extrabold text-slate-100">{avg}</p>
              <p className="text-xs text-slate-500 mt-0.5">Avg {metric.unit}</p>
            </div>
          )}
          <div className="bg-ink-800 rounded-xl p-3 text-center">
            <p className="text-2xl font-extrabold text-slate-100">{logs.length}</p>
            <p className="text-xs text-slate-500 mt-0.5">Total logs</p>
          </div>
        </div>

        {/* Calendar heatmap */}
        <div>
          <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Calendar size={14} /> Progress Calendar
          </h4>
          <MetricCalendar metric={metric} logs={logs} weeks={16} />
        </div>

        {/* Trend chart for non-boolean */}
        {!isBoolean && chartData.length > 0 && (
          <div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <TrendingUp size={14} /> Trend
            </h4>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={chartData} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="detailGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={metric.color} stopOpacity={0.4} />
                    <stop offset="95%" stopColor={metric.color} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#0d1320', border: '1px solid #1b2740', borderRadius: 12, fontSize: 12 }}
                  labelStyle={{ color: '#94a3b8' }}
                />
                <ReferenceLine y={metric.target} stroke={metric.color} strokeDasharray="4 4" strokeOpacity={0.4} />
                <Area type="monotone" dataKey="value" stroke={metric.color} strokeWidth={2.5} fill="url(#detailGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* All logs list */}
        <div>
          <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">All Logs ({logs.length})</h4>
          <div className="max-h-48 overflow-y-auto space-y-1.5">
            {sortedLogs.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-4">No logs yet</p>
            ) : (
              sortedLogs.map((log) => (
                <div key={log.date} className="flex items-center justify-between bg-ink-800/50 rounded-lg px-3 py-2">
                  <span className="text-xs text-slate-400">
                    {new Date(log.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                  </span>
                  {isBoolean ? (
                    <span className={`chip ${log.done ? 'bg-emerald-500/10 text-neon-emerald' : 'bg-ink-700 text-slate-500'}`}>
                      {log.done ? <><CheckCircle2 size={12} /> Done</> : 'Not done'}
                    </span>
                  ) : (
                    <span className="text-sm font-semibold" style={{ color: metric.color }}>
                      {log.value} {metric.unit}
                    </span>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2 pt-2 border-t border-ink-700/60">
          <button onClick={() => onEdit(metric)} className="btn-ghost flex-1 flex items-center justify-center gap-2">
            <Pencil size={16} /> Edit Metric
          </button>
          <button onClick={() => onDelete(metric)} className="btn-danger flex items-center justify-center gap-2 px-4">
            <Trash2 size={16} />
          </button>
        </div>
      </div>
    </Modal>
  );
}
