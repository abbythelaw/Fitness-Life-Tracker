import { useState, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { upsertDailyLog, removeWorkout, updateWorkout, todayStr } from '@/lib/data';
import { syncUpsertDailyLog, syncDeleteDailyLog, syncDeleteWorkout, syncUpdateWorkout, isGuest } from '@/lib/sync';
import type { DailyLog, WorkoutEntry } from '@/types';
import { History, Pencil, Trash2, X, Check, Dumbbell, Droplet, Moon, Scale, Flame, Activity } from 'lucide-react';

type LogEntry = {
  id: string;
  date: string;
  type: 'daily' | 'workout';
  label: string;
  values: { key: string; label: string; value: string; unit: string }[];
  raw: DailyLog | WorkoutEntry;
};

export function LogHistoryView() {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [filter, setFilter] = useState<'all' | 'daily' | 'workout'>('all');
  const [editingId, setEditingId] = useState<string | null>(null);

  if (!user) return null;

  const allLogs: LogEntry[] = useMemo(() => {
    const entries: LogEntry[] = [];

    for (const [date, log] of Object.entries(user.dailyLogs)) {
      const values: { key: string; label: string; value: string; unit: string }[] = [];
      if (log.weight != null) values.push({ key: 'weight', label: 'Weight', value: String(log.weight), unit: 'kg' });
      if (log.sleepHours != null) values.push({ key: 'sleepHours', label: 'Sleep', value: String(log.sleepHours), unit: 'hrs' });
      if (log.sleepQuality != null) values.push({ key: 'sleepQuality', label: 'Quality', value: String(log.sleepQuality), unit: '/100' });
      if (log.water != null) values.push({ key: 'water', label: 'Water', value: String(log.water), unit: 'glasses' });
      if (log.calories != null) values.push({ key: 'calories', label: 'Calories', value: String(log.calories), unit: 'kcal' });
      if (values.length === 0) continue;
      entries.push({ id: `daily_${date}`, date, type: 'daily', label: 'Daily Log', values, raw: log });
    }

    for (const w of user.workouts) {
      entries.push({
        id: w.id,
        date: w.date,
        type: 'workout',
        label: w.type,
        values: [
          { key: 'duration', label: 'Duration', value: String(w.duration), unit: 'min' },
          { key: 'intensity', label: 'Intensity', value: w.intensity, unit: '' },
          { key: 'calories', label: 'Calories', value: String(w.calories), unit: 'kcal' },
        ],
        raw: w,
      });
    }

    return entries.sort((a, b) => b.date.localeCompare(a.date));
  }, [user]);

  const filtered = filter === 'all' ? allLogs : allLogs.filter((l) => l.type === filter);

  const handleDeleteDaily = (date: string) => {
    updateUser((u) => {
      delete u.dailyLogs[date];
      if (!isGuest(u)) void syncDeleteDailyLog(u, date);
      return u;
    });
    showToast('Daily log deleted', 'info');
  };

  const handleDeleteWorkout = (workoutId: string) => {
    updateUser((u) => {
      removeWorkout(u, workoutId);
      return u;
    });
    showToast('Workout deleted', 'info');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-100 flex items-center gap-2">
            <History size={24} className="text-neon-cyan" /> Log History
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">View and edit every entry you've ever logged</p>
        </div>
        <div className="flex items-center gap-1 bg-ink-850 rounded-xl p-1 border border-ink-700">
          {(['all', 'daily', 'workout'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition capitalize ${
                filter === f ? 'bg-neon-cyan/10 text-neon-cyan' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {f === 'all' ? 'All' : f === 'daily' ? 'Daily' : 'Workouts'}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <History size={40} className="mx-auto text-slate-600 mb-3" />
          <p className="text-slate-400 mb-1">No logs found</p>
          <p className="text-sm text-slate-500">Start logging entries to see them here</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((entry) => {
            const isEditing = editingId === entry.id;
            return (
              <LogRow
                key={entry.id}
                entry={entry}
                isEditing={isEditing}
                onEdit={() => setEditingId(entry.id)}
                onCancelEdit={() => setEditingId(null)}
                onSaveDaily={(date, updates) => {
                  updateUser((u) => {
                    const merged = { ...u.dailyLogs[date], ...updates, date };
                    u.dailyLogs[date] = merged;
                    if (!isGuest(u)) void syncUpsertDailyLog(u, merged);
                    return u;
                  });
                  showToast('Entry updated');
                  setEditingId(null);
                }}
                onSaveWorkout={(workout) => {
                  updateUser((u) => {
                    updateWorkout(u, workout);
                    return u;
                  });
                  showToast('Workout updated');
                  setEditingId(null);
                }}
                onDelete={() => {
                  if (entry.type === 'daily') handleDeleteDaily(entry.date);
                  else handleDeleteWorkout(entry.id);
                }}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}

function LogRow({
  entry, isEditing, onEdit, onCancelEdit, onSaveDaily, onSaveWorkout, onDelete,
}: {
  entry: LogEntry;
  isEditing: boolean;
  onEdit: () => void;
  onCancelEdit: () => void;
  onSaveDaily: (date: string, updates: Partial<DailyLog>) => void;
  onSaveWorkout: (workout: WorkoutEntry) => void;
  onDelete: () => void;
}) {
  const [editValues, setEditValues] = useState<Record<string, string>>({});

  const startEdit = () => {
    const vals: Record<string, string> = {};
    for (const v of entry.values) vals[v.key] = v.value;
    setEditValues(vals);
    onEdit();
  };

  const handleSave = () => {
    if (entry.type === 'daily') {
      const updates: Partial<DailyLog> = {};
      if (editValues.weight !== undefined) updates.weight = Number(editValues.weight) || undefined;
      if (editValues.sleepHours !== undefined) updates.sleepHours = Number(editValues.sleepHours) || undefined;
      if (editValues.sleepQuality !== undefined) updates.sleepQuality = Number(editValues.sleepQuality) || undefined;
      if (editValues.water !== undefined) updates.water = Number(editValues.water) || undefined;
      if (editValues.calories !== undefined) updates.calories = Number(editValues.calories) || undefined;
      onSaveDaily(entry.date, updates);
    } else {
      const w = entry.raw as WorkoutEntry;
      onSaveWorkout({
        ...w,
        duration: Number(editValues.duration) || w.duration,
        intensity: (editValues.intensity as 'Low' | 'Medium' | 'High') || w.intensity,
        calories: Number(editValues.calories) || w.calories,
      });
    }
  };

  const Icon = entry.type === 'workout' ? Dumbbell : Activity;

  return (
    <div className="glass-card p-4 group hover:border-ink-600 transition">
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
          entry.type === 'workout' ? 'bg-neon-purple/10' : 'bg-neon-cyan/10'
        }`}>
          <Icon size={18} className={entry.type === 'workout' ? 'text-neon-purple' : 'text-neon-cyan'} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold text-slate-100 text-sm">{entry.label}</span>
            <span className="text-xs text-slate-500">
              {new Date(entry.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
            </span>
          </div>

          {isEditing ? (
            <div className="space-y-2">
              <div className="flex flex-wrap gap-2">
                {entry.values.map((v) => (
                  <div key={v.key} className="flex items-center gap-1.5 bg-ink-800 rounded-lg px-2.5 py-1.5">
                    <label className="text-xs text-slate-500">{v.label}</label>
                    {v.key === 'intensity' ? (
                      <select
                        value={editValues[v.key] || 'Medium'}
                        onChange={(e) => setEditValues((prev) => ({ ...prev, [v.key]: e.target.value }))}
                        className="bg-transparent text-xs text-slate-200 outline-none"
                      >
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                      </select>
                    ) : (
                      <input
                        type="number"
                        value={editValues[v.key] || ''}
                        onChange={(e) => setEditValues((prev) => ({ ...prev, [v.key]: e.target.value }))}
                        className="w-16 bg-transparent text-xs text-slate-200 outline-none text-right"
                      />
                    )}
                    {v.unit && <span className="text-xs text-slate-600">{v.unit}</span>}
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <button onClick={handleSave} className="btn-primary text-xs px-3 py-1.5 flex items-center gap-1">
                  <Check size={14} /> Save
                </button>
                <button onClick={onCancelEdit} className="btn-ghost text-xs px-3 py-1.5 flex items-center gap-1">
                  <X size={14} /> Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-wrap gap-x-4 gap-y-1">
              {entry.values.map((v) => (
                <div key={v.key} className="flex items-center gap-1">
                  <span className="text-xs text-slate-500">{v.label}:</span>
                  <span className="text-xs font-semibold text-slate-200">{v.value}{v.unit && ` ${v.unit}`}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {!isEditing && (
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
            <button
              onClick={startEdit}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-neon-cyan hover:bg-cyan-500/10 transition"
            >
              <Pencil size={14} />
            </button>
            <button
              onClick={onDelete}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition"
            >
              <Trash2 size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
