import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Activity, Mail, Lock, User, Eye, EyeOff, ArrowRight, Loader2, Shield } from 'lucide-react';

export function LoginScreen() {
  const { login, signup, loginAsGuest } = useAuth();
  const { showToast } = useToast();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result = mode === 'login'
        ? await login(email, password)
        : await signup(name, email, password);
      if (!result.ok) {
        setError(result.error || 'Something went wrong.');
      } else {
        showToast(mode === 'login' ? 'Welcome back!' : 'Account created successfully!');
      }
    } catch {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleGuest = () => {
    loginAsGuest();
    showToast('Exploring as guest with sample data', 'info');
  };

  const handleAdmin = async () => {
    setError('');
    setLoading(true);
    try {
      const result = await login('admin_abner@vitaltrack.app', 'Asdfgzxcv12!');
      if (!result.ok) {
        setError(result.error || 'Admin login failed.');
      } else {
        showToast('Welcome, Admin!');
      }
    } catch {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left visual panel */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-ink-900 via-ink-850 to-ink-950">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-20 w-72 h-72 bg-neon-emerald rounded-full blur-[120px]" />
          <div className="absolute bottom-20 right-10 w-72 h-72 bg-neon-cyan rounded-full blur-[120px]" />
          <div className="absolute top-1/2 left-1/2 w-72 h-72 bg-neon-purple rounded-full blur-[120px] opacity-50" />
        </div>
        <div className="relative z-10 flex flex-col justify-center px-16 py-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-neon-emerald/10 flex items-center justify-center neon-border-emerald">
              <Activity size={26} className="text-neon-emerald" />
            </div>
            <span className="text-2xl font-extrabold text-slate-100">VitalTrack</span>
          </div>
          <h1 className="text-4xl font-extrabold text-slate-100 leading-tight mb-4">
            Your health,<br />
            <span className="neon-text-emerald">visualized.</span>
          </h1>
          <p className="text-slate-400 text-lg leading-relaxed max-w-md">
            Track weight, sleep, hydration, workouts, and custom metrics — all in one beautifully crafted dashboard.
          </p>
          <div className="mt-10 space-y-3">
            {[
              'Dynamic custom metric builder',
              'Interactive charts with trend analysis',
              'Auto-calculating BMI & progress rings',
            ].map((f) => (
              <div key={f} className="flex items-center gap-3 text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-neon-emerald" />
                <span className="text-sm">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right form panel */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-10 bg-ink-950">
        <div className="w-full max-w-sm animate-fade-in">
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="w-11 h-11 rounded-2xl bg-neon-emerald/10 flex items-center justify-center neon-border-emerald">
              <Activity size={24} className="text-neon-emerald" />
            </div>
            <span className="text-xl font-extrabold text-slate-100">VitalTrack</span>
          </div>

          <h2 className="text-2xl font-bold text-slate-100 mb-1">
            {mode === 'login' ? 'Welcome back' : 'Create your account'}
          </h2>
          <p className="text-slate-400 text-sm mb-6">
            {mode === 'login' ? 'Sign in to view your dashboard' : 'Start tracking your health today'}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">Full Name</label>
                <div className="relative">
                  <User size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Doe"
                    required
                    className="input-field pl-11"
                  />
                </div>
              </div>
            )}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">Email</label>
              <div className="relative">
                <Mail size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="input-field pl-11"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">Password</label>
              <div className="relative">
                <Lock size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  minLength={4}
                  className="input-field pl-11 pr-11"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((s) => !s)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition"
                >
                  {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-2.5 text-sm text-red-400 animate-slide-down">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-60">
              {loading ? (
                <><Loader2 size={16} className="animate-spin" /> Please wait...</>
              ) : (
                <>
                  {mode === 'login' ? 'Sign In' : 'Create Account'}
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-ink-700" />
            <span className="text-xs text-slate-500">or</span>
            <div className="flex-1 h-px bg-ink-700" />
          </div>

          <button
            onClick={handleGuest}
            className="btn-ghost w-full flex items-center justify-center gap-2"
          >
            <Activity size={16} />
            Continue as Guest
          </button>

          <button
            onClick={handleAdmin}
            disabled={loading}
            className="btn-ghost w-full flex items-center justify-center gap-2 mt-2 disabled:opacity-60"
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : <Shield size={16} />}
            Continue as Admin
          </button>

          <p className="text-center text-sm text-slate-400 mt-6">
            {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
            <button
              onClick={() => {
                setMode(mode === 'login' ? 'signup' : 'login');
                setError('');
              }}
              className="text-neon-emerald font-semibold hover:underline"
            >
              {mode === 'login' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
