import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import {
  startFastingSession, endFastingSession, getActiveFastingSession,
  getFastingStage, getNextStage, formatDuration, FASTING_STAGES,
} from '@/lib/data';
import type { FastingSession } from '@/types';
import { Timer, Play, Square, Clock, Flame, Zap, Atom, Droplet, Sparkles, History } from 'lucide-react';

const PRESETS = [
  { hours: 12, label: '12:12', desc: 'Circadian Rhythm' },
  { hours: 14, label: '14:10', desc: 'Beginner' },
  { hours: 16, label: '16:8', desc: 'Most Popular' },
  { hours: 18, label: '18:6', desc: 'Intermediate' },
  { hours: 20, label: '20:4', desc: 'Warrior Diet' },
  { hours: 24, label: '24hr', desc: 'Autophagy' },
];

export function FastingView() {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [now, setNow] = useState(Date.now());
  const [customHours, setCustomHours] = useState('');

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  if (!user) return null;

  const activeSession = getActiveFastingSession(user);
  const elapsedMs = activeSession ? now - activeSession.startedAt : 0;
  const elapsedHours = elapsedMs / (3600 * 1000);
  const stage = getFastingStage(elapsedHours);
  const nextStage = getNextStage(elapsedHours);
  const progressPct = activeSession ? Math.min(100, (elapsedMs / (activeSession.expectedEnd - activeSession.startedAt)) * 100) : 0;

  const completedSessions = (user.fastingSessions || []).filter((s) => s.endedAt !== null).slice(0, 10);

  const handleStart = (hours: number, label: string) => {
    updateUser((u) => startFastingSession(u, hours, label));
    showToast(`Fasting timer started: ${label}`);
  };

  const handleEnd = () => {
    if (!activeSession) return;
    updateUser((u) => endFastingSession(u, activeSession.id));
    showToast('Fasting session completed!');
  };

  const handleCustomStart = () => {
    const h = Number(customHours);
    if (!h || h < 1) {
      showToast('Enter a valid number of hours', 'error');
      return;
    }
    handleStart(h, `${h}hr Custom Fast`);
    setCustomHours('');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-100 flex items-center gap-2">
          <Timer size={24} className="text-neon-amber" /> Fasting Tracker
        </h1>
        <p className="text-sm text-slate-400 mt-0.5">Track intermittent fasting with real-time stage progression</p>
      </div>

      {/* Active Timer or Start Panel */}
      {activeSession ? (
        <div className="glass-card p-6 sm:p-8 animate-scale-in" style={{ boxShadow: `0 0 40px ${stage.color}15` }}>
          <div className="flex flex-col items-center text-center">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 rounded-full animate-pulse" style={{ backgroundColor: stage.color, boxShadow: `0 0 10px ${stage.color}` }} />
              <span className="text-sm font-semibold uppercase tracking-wider" style={{ color: stage.color }}>{stage.label}</span>
            </div>
            <p className="text-sm text-slate-400 mb-6 max-w-sm">{stage.desc}</p>

            {/* Big Timer */}
            <div className="relative">
              <svg width="220" height="220" className="-rotate-90">
                <circle cx="110" cy="110" r="100" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="10" />
                <circle
                  cx="110" cy="110" r="100" fill="none"
                  stroke={stage.color} strokeWidth="10" strokeLinecap="round"
                  strokeDasharray={2 * Math.PI * 100}
                  strokeDashoffset={2 * Math.PI * 100 * (1 - progressPct / 100)}
                  style={{ transition: 'stroke-dashoffset 1s ease', filter: `drop-shadow(0 0 8px ${stage.color}80)` }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-extrabold text-slate-100 tabular-nums tracking-tight">{formatDuration(elapsedMs)}</span>
                <span className="text-xs text-slate-500 mt-1">elapsed</span>
              </div>
            </div>

            {/* Expected End */}
            <div className="grid grid-cols-3 gap-3 mt-6 w-full max-w-md">
              <div className="bg-ink-800 rounded-xl p-3 text-center">
                <Clock size={16} className="mx-auto text-slate-500 mb-1" />
                <p className="text-xs text-slate-500">Started</p>
                <p className="text-sm font-semibold text-slate-200">{new Date(activeSession.startedAt).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</p>
              </div>
              <div className="bg-ink-800 rounded-xl p-3 text-center">
                <Sparkles size={16} className="mx-auto text-slate-500 mb-1" />
                <p className="text-xs text-slate-500">Target</p>
                <p className="text-sm font-semibold text-slate-200">{activeSession.targetHours}h</p>
              </div>
              <div className="bg-ink-800 rounded-xl p-3 text-center">
                <Timer size={16} className="mx-auto text-slate-500 mb-1" />
                <p className="text-xs text-slate-500">Expected End</p>
                <p className="text-sm font-semibold text-slate-200">{new Date(activeSession.expectedEnd).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</p>
              </div>
            </div>

            {nextStage && (
              <div className="mt-4 flex items-center gap-2 text-xs text-slate-500">
                <span>Next stage:</span>
                <span className="font-semibold" style={{ color: nextStage.color }}>{nextStage.label}</span>
                <span>in {(nextStage.hours - elapsedHours).toFixed(1)}h</span>
              </div>
            )}

            <button onClick={handleEnd} className="btn-danger mt-6 flex items-center gap-2 px-8">
              <Square size={16} /> End Fast
            </button>
          </div>
        </div>
      ) : (
        <div className="glass-card p-6">
          <h3 className="font-semibold text-slate-100 mb-4 flex items-center gap-2">
            <Play size={18} className="text-neon-emerald" /> Start a Fast
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {PRESETS.map((p) => (
              <button
                key={p.hours}
                onClick={() => handleStart(p.hours, `${p.label} Fast`)}
                className="bg-ink-800 border border-ink-600 rounded-xl p-4 text-left hover:border-neon-amber/40 hover:bg-ink-750 transition group"
              >
                <p className="text-lg font-extrabold text-slate-100 group-hover:text-neon-amber transition">{p.label}</p>
                <p className="text-xs text-slate-500">{p.desc}</p>
                <p className="text-xs text-slate-600 mt-1">{p.hours} hours</p>
              </button>
            ))}
          </div>
          <div className="mt-4 flex gap-2">
            <input
              type="number"
              value={customHours}
              onChange={(e) => setCustomHours(e.target.value)}
              placeholder="Custom hours"
              className="input-field flex-1"
              min={1}
            />
            <button onClick={handleCustomStart} className="btn-primary flex items-center gap-2">
              <Play size={16} /> Start
            </button>
          </div>
        </div>
      )}

      {/* Fasting Stages Infographic */}
      <div className="glass-card p-5">
        <h3 className="font-semibold text-slate-100 mb-4 flex items-center gap-2">
          <Zap size={18} className="text-neon-purple" /> Fasting Stages Timeline
        </h3>
        <div className="relative">
          {/* Progress line */}
          <div className="absolute left-0 right-0 top-5 h-0.5 bg-ink-700 rounded-full" />
          <div
            className="absolute left-0 top-5 h-0.5 rounded-full transition-all duration-1000"
            style={{ width: `${Math.min(100, (elapsedHours / 24) * 100)}%`, background: `linear-gradient(90deg, ${FASTING_STAGES.map((s) => s.color).join(', ')})` }}
          />
          <div className="relative flex justify-between">
            {FASTING_STAGES.map((s) => {
              const isActive = elapsedHours >= s.hours;
              const isCurrent = stage.stage === s.stage;
              return (
                <div key={s.stage} className="flex flex-col items-center gap-2" style={{ width: '20%' }}>
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${isActive ? 'border-transparent' : 'border-ink-600'}`}
                    style={{
                      backgroundColor: isActive ? s.color : 'transparent',
                      boxShadow: isCurrent ? `0 0 15px ${s.color}80` : 'none',
                      transform: isCurrent ? 'scale(1.15)' : 'scale(1)',
                    }}
                  >
                    {s.stage === 'fed' && <Droplet size={16} className={isActive ? 'text-ink-950' : 'text-slate-600'} />}
                    {s.stage === 'early' && <Clock size={16} className={isActive ? 'text-ink-950' : 'text-slate-600'} />}
                    {s.stage === 'fatBurning' && <Flame size={16} className={isActive ? 'text-ink-950' : 'text-slate-600'} />}
                    {s.stage === 'ketosis' && <Zap size={16} className={isActive ? 'text-ink-950' : 'text-slate-600'} />}
                    {s.stage === 'autophagy' && <Atom size={16} className={isActive ? 'text-ink-950' : 'text-slate-600'} />}
                  </div>
                  <div className="text-center">
                    <p className={`text-xs font-semibold ${isCurrent ? '' : isActive ? 'text-slate-300' : 'text-slate-600'}`} style={isCurrent ? { color: s.color } : {}}>{s.label}</p>
                    <p className="text-[10px] text-slate-600">{s.hours}h+</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-6">
          {FASTING_STAGES.map((s) => (
            <div key={s.stage} className="bg-ink-800/50 rounded-xl p-3 border-l-2" style={{ borderColor: s.color }}>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
                <p className="text-sm font-semibold text-slate-200">{s.label}</p>
                <span className="text-xs text-slate-600 ml-auto">{s.hours}h+</span>
              </div>
              <p className="text-xs text-slate-500">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* History */}
      {completedSessions.length > 0 && (
        <div className="glass-card p-5">
          <h3 className="font-semibold text-slate-100 mb-4 flex items-center gap-2">
            <History size={18} className="text-neon-cyan" /> Fasting History
          </h3>
          <div className="space-y-2">
            {completedSessions.map((s) => {
              const duration = (s.endedAt! - s.startedAt) / (3600 * 1000);
              const achieved = duration >= s.targetHours;
              return (
                <div key={s.id} className="bg-ink-800/50 rounded-xl p-3 flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${achieved ? 'bg-emerald-500/10' : 'bg-amber-500/10'}`}>
                    {achieved ? <Flame size={18} className="text-neon-emerald" /> : <Clock size={18} className="text-neon-amber" />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-slate-200">{s.label}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(s.startedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      {' · '}{duration.toFixed(1)}h / {s.targetHours}h target
                    </p>
                  </div>
                  <span className={`chip ${achieved ? 'bg-emerald-500/10 text-neon-emerald' : 'bg-amber-500/10 text-neon-amber'}`}>
                    {achieved ? 'Completed' : 'Partial'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
