import { useState, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { ProgressRing } from '@/components/ui/ProgressRing';
import { Modal } from '@/components/ui/Modal';
import {
  calcBMI, bmiStatus, getLatestLog, getLogForDate, todayStr,
  toggleCardVisibility, reorderCards, setDashboardLayout,
  logSingleDailyMetric, getCategoryName, getCategoryColor,
} from '@/lib/data';
import {
  Scale, Flame, Moon, Droplets, HeartPulse, LayoutGrid, Rows3,
  Eye, EyeOff, GripVertical, ChevronUp, ChevronDown, Plus, X, Check, Pencil, Settings2,
} from 'lucide-react';
import type { BuiltInMetricId } from '@/components/BuiltInMetricDetail';

const BUILTIN_CARD_IDS: (BuiltInMetricId)[] = ['bmi', 'weight', 'calories', 'sleep', 'water'];

export function OverviewCards({ onMetricClick }: { onMetricClick: (id: BuiltInMetricId) => void }) {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [customizeOpen, setCustomizeOpen] = useState(false);
  const [quickLog, setQuickLog] = useState<BuiltInMetricId | null>(null);

  if (!user) return null;

  const today = todayStr();
  const todayLog = getLogForDate(user, today);
  const latest = getLatestLog(user);
  const weight = todayLog?.weight ?? latest?.weight ?? 0;
  const bmi = calcBMI(weight, user.height);
  const status = bmiStatus(bmi);
  const sleepHours = todayLog?.sleepHours ?? 0;
  const sleepQuality = todayLog?.sleepQuality ?? 0;
  const water = todayLog?.water ?? 0;
  const calories = todayLog?.calories ?? 0;
  const targets = user.dailyTargets;

  const prefs = user.dashboardPrefs || { layout: 'grid' as const, cardOrder: [], hiddenCards: [] };
  const hidden = new Set(prefs.hiddenCards);
  const layout = prefs.layout || 'grid';

  // Determine card order
  const order = prefs.cardOrder.length > 0
    ? prefs.cardOrder
    : BUILTIN_CARD_IDS;

  // All cards data
  const cardData: Record<string, {
    label: string; value: string; unit: string; icon: React.ReactNode; iconBg: string;
    ringValue: number; ringMax: number; ringColor: string; ringLabel: string; ringSublabel: string;
    progress: number; progressColor: string; extra?: React.ReactNode;
    category?: string; categoryColor?: string;
  }> = {
    bmi: {
      label: 'BMI Index', value: bmi ? `${bmi}` : '--', unit: 'kg/m²',
      icon: <Scale size={22} className="text-neon-purple" />, iconBg: 'bg-neon-purple/10',
      ringValue: bmi, ringMax: 40, ringColor: '#a855f7',
      ringLabel: status.label, ringSublabel: `${weight}kg · ${user.height}cm`,
      progress: Math.min(100, (bmi / 40) * 100), progressColor: 'from-cyan-500 to-purple-500',
      category: 'Overall Health', categoryColor: '#a855f7',
    },
    weight: {
      label: 'Current Weight', value: weight ? `${weight}` : '--', unit: 'kg',
      icon: <Scale size={22} className="text-neon-emerald" />, iconBg: 'bg-neon-emerald/10',
      ringValue: weight, ringMax: Math.max(targets.weight * 1.3, weight || 100), ringColor: '#10b981',
      ringLabel: weight ? `${Math.round((weight / targets.weight) * 100)}%` : '--', ringSublabel: `Goal ${targets.weight}kg`,
      progress: weight ? Math.min(100, (weight / (targets.weight * 1.3)) * 100) : 0, progressColor: 'from-neon-emerald to-emerald-400',
      category: 'Overall Health', categoryColor: '#10b981',
    },
    calories: {
      label: 'Active Calories', value: `${calories}`, unit: 'kcal',
      icon: <Flame size={22} className="text-neon-amber" />, iconBg: 'bg-amber-500/10',
      ringValue: calories, ringMax: targets.calories, ringColor: '#f59e0b',
      ringLabel: `${Math.round((calories / targets.calories) * 100)}%`, ringSublabel: `Goal ${targets.calories}`,
      progress: Math.min(100, (calories / targets.calories) * 100), progressColor: 'from-amber-500 to-neon-amber',
      category: 'Exercise Related', categoryColor: '#f59e0b',
    },
    sleep: {
      label: 'Sleep', value: `${sleepHours}`, unit: 'hrs',
      icon: <Moon size={22} className="text-neon-cyan" />, iconBg: 'bg-cyan-500/10',
      ringValue: sleepHours, ringMax: targets.sleep, ringColor: '#06b6d4',
      ringLabel: `${Math.round((sleepHours / targets.sleep) * 100)}%`, ringSublabel: `Quality ${sleepQuality}/100`,
      progress: Math.min(100, (sleepHours / targets.sleep) * 100), progressColor: 'from-cyan-500 to-neon-cyan',
      extra: (
        <div className="flex items-center gap-2 mt-2">
          <HeartPulse size={14} className="text-neon-cyan" />
          <div className="flex-1 h-1.5 bg-ink-700 rounded-full overflow-hidden">
            <div className="h-full bg-neon-cyan rounded-full transition-all duration-700" style={{ width: `${sleepQuality}%` }} />
          </div>
          <span className="text-xs text-slate-400 font-medium">{sleepQuality}</span>
        </div>
      ),
      category: 'Overall Health', categoryColor: '#06b6d4',
    },
    water: {
      label: 'Water Intake', value: `${water}`, unit: 'glasses',
      icon: <Droplets size={22} className="text-blue-400" />, iconBg: 'bg-blue-500/10',
      ringValue: water, ringMax: targets.water, ringColor: '#3b82f6',
      ringLabel: `${Math.round((water / targets.water) * 100)}%`, ringSublabel: `Goal ${targets.water}`,
      progress: Math.min(100, (water / targets.water) * 100), progressColor: 'from-blue-500 to-blue-400',
      category: 'Overall Health', categoryColor: '#3b82f6',
    },
  };

  const visibleCards = order.filter((id) => !hidden.has(id) && cardData[id]);
  const gridClass = layout === 'grid'
    ? 'grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4'
    : 'flex flex-col gap-4 max-w-2xl';

  const handleQuickLog = (id: BuiltInMetricId, value: string) => {
    const numVal = Number(value);
    if (isNaN(numVal)) {
      showToast('Please enter a valid number', 'error');
      return;
    }
    const fieldMap: Record<BuiltInMetricId, 'weight' | 'calories' | 'sleepHours' | 'water'> = {
      weight: 'weight', calories: 'calories', sleep: 'sleepHours', water: 'water', bmi: 'weight',
    };
    updateUser((u) => logSingleDailyMetric(u, fieldMap[id], numVal));
    showToast(`${id === 'bmi' ? 'Weight' : id.charAt(0).toUpperCase() + id.slice(1)} logged: ${numVal}`);
    setQuickLog(null);
  };

  return (
    <div>
      {/* Header with layout toggle and customize button */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-slate-100">Health Snapshot</h2>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-ink-850 rounded-xl p-1 border border-ink-700">
            <button
              onClick={() => updateUser((u) => setDashboardLayout(u, 'grid'))}
              className={`w-8 h-8 rounded-lg flex items-center justify-center transition ${layout === 'grid' ? 'bg-neon-emerald/10 text-neon-emerald' : 'text-slate-400 hover:text-slate-200'}`}
              title="Grid Layout"
            >
              <LayoutGrid size={16} />
            </button>
            <button
              onClick={() => updateUser((u) => setDashboardLayout(u, 'stack'))}
              className={`w-8 h-8 rounded-lg flex items-center justify-center transition ${layout === 'stack' ? 'bg-neon-emerald/10 text-neon-emerald' : 'text-slate-400 hover:text-slate-200'}`}
              title="Stack Layout"
            >
              <Rows3 size={16} />
            </button>
          </div>
          <button
            onClick={() => setCustomizeOpen(true)}
            className="btn-ghost text-xs flex items-center gap-1.5"
          >
            <Settings2 size={14} /> Customize
          </button>
        </div>
      </div>

      {/* Cards */}
      <div className={gridClass}>
        {visibleCards.map((id) => {
          const card = cardData[id];
          if (!card) return null;
          const canQuickLog = id !== 'bmi';
          return (
            <div
              key={id}
              className="glass-card p-5 animate-slide-up hover:border-ink-600 transition group cursor-pointer relative"
              onClick={() => onMetricClick(id)}
            >
              {/* Category tag */}
              {card.category && (
                <span
                  className="absolute top-3 right-3 text-[10px] font-semibold px-2 py-0.5 rounded-full"
                  style={{ backgroundColor: `${card.categoryColor}20`, color: card.categoryColor }}
                >
                  {card.category}
                </span>
              )}

              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{card.label}</p>
                  <div className="flex items-baseline gap-1.5 mt-1">
                    <span className="text-3xl font-extrabold text-slate-100">{card.value}</span>
                    <span className="text-sm text-slate-500">{card.unit}</span>
                  </div>
                </div>
                <div className={`w-11 h-11 rounded-xl ${card.iconBg} flex items-center justify-center group-hover:scale-110 transition`}>
                  {card.icon}
                </div>
              </div>

              <div className="flex items-center gap-4">
                <ProgressRing value={card.ringValue} max={card.ringMax} size={72} strokeWidth={6} color={card.ringColor} label={card.ringLabel} sublabel="" />
                <div className="flex-1">
                  <p className="text-xs text-slate-500 mb-1">{card.ringSublabel}</p>
                  <div className="h-2 bg-ink-700 rounded-full overflow-hidden">
                    <div className={`h-full bg-gradient-to-r ${card.progressColor} rounded-full transition-all duration-700`} style={{ width: `${card.progress}%` }} />
                  </div>
                  {card.extra}
                </div>
              </div>

              {/* Quick log button */}
              {canQuickLog && (
                <button
                  onClick={(e) => { e.stopPropagation(); setQuickLog(id); }}
                  className="mt-3 w-full py-1.5 rounded-lg bg-ink-800 text-xs text-slate-400 hover:text-slate-200 hover:bg-ink-750 transition flex items-center justify-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Plus size={12} /> Quick Log
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Hidden cards notice */}
      {hidden.size > 0 && (
        <p className="text-xs text-slate-600 mt-3 text-center">
          {hidden.size} card{hidden.size !== 1 ? 's' : ''} hidden — use Customize to show them
        </p>
      )}

      {/* Customize Dashboard Modal */}
      <CustomizeDashboardModal
        open={customizeOpen}
        onClose={() => setCustomizeOpen(false)}
        order={order}
        hidden={hidden}
        onToggle={(id) => {
          updateUser((u) => toggleCardVisibility(u, id));
          showToast(hidden.has(id) ? 'Card shown' : 'Card hidden', 'info');
        }}
        onMoveUp={(id, idx) => {
          if (idx === 0) return;
          const newOrder = [...order];
          [newOrder[idx - 1], newOrder[idx]] = [newOrder[idx], newOrder[idx - 1]];
          updateUser((u) => reorderCards(u, newOrder));
        }}
        onMoveDown={(id, idx) => {
          if (idx === order.length - 1) return;
          const newOrder = [...order];
          [newOrder[idx], newOrder[idx + 1]] = [newOrder[idx + 1], newOrder[idx]];
          updateUser((u) => reorderCards(u, newOrder));
        }}
        cardLabels={{
          bmi: 'BMI Index', weight: 'Current Weight', calories: 'Active Calories',
          sleep: 'Sleep', water: 'Water Intake',
        }}
      />

      {/* Quick Log Modal */}
      <QuickLogModal
        metricId={quickLog}
        onClose={() => setQuickLog(null)}
        onSave={(value) => quickLog && handleQuickLog(quickLog, value)}
      />
    </div>
  );
}

function CustomizeDashboardModal({
  open, onClose, order, hidden, onToggle, onMoveUp, onMoveDown, cardLabels,
}: {
  open: boolean;
  onClose: () => void;
  order: string[];
  hidden: Set<string>;
  onToggle: (id: string) => void;
  onMoveUp: (id: string, idx: number) => void;
  onMoveDown: (id: string, idx: number) => void;
  cardLabels: Record<string, string>;
}) {
  return (
    <Modal open={open} onClose={onClose} title="Customize Dashboard" subtitle="Show, hide, and reorder your snapshot cards" icon={<Settings2 size={20} />}>
      <div className="space-y-2">
        {order.map((id, idx) => {
          const isHidden = hidden.has(id);
          return (
            <div key={id} className={`flex items-center gap-3 bg-ink-800 rounded-xl p-3 ${isHidden ? 'opacity-50' : ''}`}>
              <GripVertical size={16} className="text-slate-600" />
              <span className="flex-1 text-sm font-medium text-slate-200">{cardLabels[id] || id}</span>
              <button
                onClick={() => onMoveUp(id, idx)}
                disabled={idx === 0}
                className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-200 hover:bg-ink-700 transition disabled:opacity-30"
              >
                <ChevronUp size={16} />
              </button>
              <button
                onClick={() => onMoveDown(id, idx)}
                disabled={idx === order.length - 1}
                className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-200 hover:bg-ink-700 transition disabled:opacity-30"
              >
                <ChevronDown size={16} />
              </button>
              <button
                onClick={() => onToggle(id)}
                className={`w-8 h-8 rounded-lg flex items-center justify-center transition ${
                  isHidden ? 'text-slate-500 hover:text-neon-emerald hover:bg-emerald-500/10' : 'text-slate-400 hover:text-red-400 hover:bg-red-500/10'
                }`}
                title={isHidden ? 'Show' : 'Hide'}
              >
                {isHidden ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          );
        })}
      </div>
      <div className="flex gap-2 pt-4">
        <button onClick={onClose} className="btn-primary flex-1">Done</button>
      </div>
    </Modal>
  );
}

function QuickLogModal({
  metricId, onClose, onSave,
}: {
  metricId: BuiltInMetricId | null;
  onClose: () => void;
  onSave: (value: string) => void;
}) {
  const [value, setValue] = useState('');

  const labels: Record<BuiltInMetricId, string> = {
    bmi: 'Weight', weight: 'Weight', calories: 'Calories', sleep: 'Sleep Hours', water: 'Water Glasses',
  };
  const units: Record<BuiltInMetricId, string> = {
    bmi: 'kg', weight: 'kg', calories: 'kcal', sleep: 'hrs', water: 'glasses',
  };

  return (
    <Modal open={!!metricId} onClose={onClose} title={`Quick Log: ${metricId ? labels[metricId] : ''}`} subtitle="Log just this metric for today" icon={<Plus size={20} />}>
      <form onSubmit={(e) => { e.preventDefault(); onSave(value); }} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">
            {metricId ? labels[metricId] : ''} ({metricId ? units[metricId] : ''})
          </label>
          <input
            type="number"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Enter value"
            className="input-field"
            required
            autoFocus
            step="0.1"
          />
        </div>
        <div className="flex gap-2 pt-2">
          <button type="button" onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button type="submit" className="btn-primary flex-1 flex items-center justify-center gap-2">
            <Check size={16} /> Save
          </button>
        </div>
      </form>
    </Modal>
  );
}
