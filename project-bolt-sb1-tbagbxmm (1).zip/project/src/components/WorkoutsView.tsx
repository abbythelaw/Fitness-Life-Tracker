import { useState, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { getRecentWorkouts } from '@/lib/data';
import { Dumbbell, Clock, Flame, Trash2, Plus, Filter } from 'lucide-react';
import type { WorkoutEntry } from '@/types';

export function WorkoutsView({ onLogWorkout }: { onLogWorkout: () => void }) {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [range, setRange] = useState<7 | 30 | 90>(7);

  const workouts = useMemo(() => {
    if (!user) return [];
    return getRecentWorkouts(user, range).slice().sort((a, b) => b.date.localeCompare(a.date));
  }, [user, range]);

  if (!user) return null;

  const totalCalories = workouts.reduce((s, w) => s + w.calories, 0);
  const totalDuration = workouts.reduce((s, w) => s + w.duration, 0);

  const handleDelete = (id: string) => {
    updateUser((u) => {
      u.workouts = u.workouts.filter((w) => w.id !== id);
      return u;
    });
    showToast('Workout deleted', 'info');
  };

  const intensityColor = (i: WorkoutEntry['intensity']) =>
    i === 'Low' ? 'text-neon-cyan bg-cyan-500/10'
      : i === 'Medium' ? 'text-neon-amber bg-amber-500/10'
        : 'text-red-400 bg-red-500/10';

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <Dumbbell size={20} className="text-neon-purple" /> Workout History
        </h2>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-ink-850 rounded-xl p-1 border border-ink-700">
            {([7, 30, 90] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                  range === r ? 'bg-neon-purple/10 text-neon-purple' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {r}D
              </button>
            ))}
          </div>
          <button onClick={onLogWorkout} className="btn-primary text-xs flex items-center gap-1.5">
            <Plus size={14} /> Log Workout
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="glass-card p-4 flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-500/10 flex items-center justify-center">
            <Flame size={22} className="text-neon-amber" />
          </div>
          <div>
            <p className="text-2xl font-extrabold text-slate-100">{totalCalories}</p>
            <p className="text-xs text-slate-500">Total calories burned</p>
          </div>
        </div>
        <div className="glass-card p-4 flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-neon-purple/10 flex items-center justify-center">
            <Clock size={22} className="text-neon-purple" />
          </div>
          <div>
            <p className="text-2xl font-extrabold text-slate-100">{totalDuration}</p>
            <p className="text-xs text-slate-500">Total minutes exercised</p>
          </div>
        </div>
      </div>

      {workouts.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Dumbbell size={40} className="mx-auto text-slate-600 mb-3" />
          <p className="text-slate-400 mb-1">No workouts logged in this period</p>
          <p className="text-sm text-slate-500">Tap "Log Workout" to record your first session</p>
        </div>
      ) : (
        <div className="space-y-2">
          {workouts.map((w) => (
            <div key={w.id} className="glass-card p-4 flex items-center gap-4 group hover:border-ink-600 transition animate-slide-up">
              <div className="w-12 h-12 rounded-xl bg-neon-purple/10 flex items-center justify-center shrink-0">
                <Dumbbell size={22} className="text-neon-purple" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="font-semibold text-slate-100">{w.type}</h4>
                  <span className={`chip ${intensityColor(w.intensity)}`}>{w.intensity}</span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  {new Date(w.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                  {' · '}{w.duration} min{' · '}{w.calories} kcal
                </p>
              </div>
              <button
                onClick={() => handleDelete(w.id)}
                className="opacity-0 group-hover:opacity-100 w-9 h-9 rounded-lg flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition"
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
