import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Modal } from '@/components/ui/Modal';
import { upsertDailyLog, addWorkout, addCustomMetric, updateCustomMetric, todayStr, getLogForDate, getMetricLogs } from '@/lib/data';
import { syncUpsertDailyLog, syncUpsertMetricLog, syncInsertWorkout, isGuest } from '@/lib/sync';
import type { MetricType, WorkoutEntry, CustomMetric } from '@/types';
import { ClipboardList, Dumbbell, Activity, Plus, Check, X, Pencil } from 'lucide-react';

interface LogEntryModalProps {
  open: boolean;
  onClose: () => void;
}

export function LogEntryModal({ open, onClose }: LogEntryModalProps) {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const today = todayStr();

  const [date, setDate] = useState(today);
  const [weight, setWeight] = useState('');
  const [sleepHours, setSleepHours] = useState('');
  const [sleepQuality, setSleepQuality] = useState('');
  const [water, setWater] = useState('');
  const [calories, setCalories] = useState('');
  const [customValues, setCustomValues] = useState<Record<string, string>>({});
  const [customDone, setCustomDone] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (open && user) {
      const ex = getLogForDate(user, date);
      setWeight(ex?.weight?.toString() || '');
      setSleepHours(ex?.sleepHours?.toString() || '');
      setSleepQuality(ex?.sleepQuality?.toString() || '');
      setWater(ex?.water?.toString() || '');
      setCalories(ex?.calories?.toString() || '');
      const cv: Record<string, string> = {};
      const cd: Record<string, boolean> = {};
      for (const m of user.customMetrics) {
        const logs = getMetricLogs(user, m.id);
        const dayLog = logs.find((l) => l.date === date);
        if (m.type === 'boolean') {
          cd[m.id] = dayLog?.done || false;
        } else {
          cv[m.id] = dayLog?.value?.toString() || '';
        }
      }
      setCustomValues(cv);
      setCustomDone(cd);
    }
  }, [open, user, date]);

  if (!user) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const log: Partial<{ date: string; weight: number; sleepHours: number; sleepQuality: number; water: number; calories: number }> = { date };
    if (weight) log.weight = Number(weight);
    if (sleepHours) log.sleepHours = Number(sleepHours);
    if (sleepQuality) log.sleepQuality = Number(sleepQuality);
    if (water) log.water = Number(water);
    if (calories) log.calories = Number(calories);

    updateUser((u) => {
      upsertDailyLog(u, log as Parameters<typeof upsertDailyLog>[1]);
      for (const m of u.customMetrics) {
        const logs = u.customMetricLogs[m.id] || [];
        const idx = logs.findIndex((l) => l.date === date);
        if (m.type === 'boolean') {
          const done = customDone[m.id] || false;
          let logEntry;
          if (idx >= 0) {
            logs[idx].done = done;
            logs[idx].value = done ? 1 : 0;
            logEntry = logs[idx];
          } else {
            logEntry = { date, value: done ? 1 : 0, done };
            logs.push(logEntry);
          }
          if (!isGuest(u)) void syncUpsertMetricLog(u, m.id, logEntry);
        } else {
          const val = customValues[m.id];
          if (val) {
            let logEntry;
            if (idx >= 0) {
              logs[idx].value = Number(val);
              logEntry = logs[idx];
            } else {
              logEntry = { date, value: Number(val) };
              logs.push(logEntry);
            }
            if (!isGuest(u)) void syncUpsertMetricLog(u, m.id, logEntry);
          }
        }
        u.customMetricLogs[m.id] = logs;
      }
      return u;
    });
    showToast('Entry logged successfully');
    onClose();
  };

  const isEditing = date !== today;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isEditing ? 'Edit Entry' : 'Log Health Entry'}
      subtitle={isEditing ? `Editing ${new Date(date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}` : 'Record your daily metrics'}
      icon={<ClipboardList size={20} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Date {isEditing && <span className="text-neon-amber">(editing past day)</span>}</label>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input-field" max={today} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Weight (kg)" value={weight} onChange={setWeight} type="number" step="0.1" placeholder="72.5" />
          <Field label="Water (glasses)" value={water} onChange={setWater} type="number" placeholder="8" />
          <Field label="Sleep (hrs)" value={sleepHours} onChange={setSleepHours} type="number" step="0.5" placeholder="7.5" />
          <Field label="Sleep Quality (1-100)" value={sleepQuality} onChange={setSleepQuality} type="number" placeholder="85" />
          <Field label="Active Calories (kcal)" value={calories} onChange={setCalories} type="number" placeholder="450" />
        </div>

        {user.customMetrics.length > 0 && (
          <div className="pt-2 border-t border-ink-700/60">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Custom Metrics</p>
            <div className="grid grid-cols-2 gap-3">
              {user.customMetrics.map((m) =>
                m.type === 'boolean' ? (
                  <div key={m.id} className="flex items-center justify-between bg-ink-800 rounded-xl px-4 py-2.5">
                    <label className="text-xs font-semibold text-slate-400">{m.name}</label>
                    <button
                      type="button"
                      onClick={() => setCustomDone((prev) => ({ ...prev, [m.id]: !prev[m.id] }))}
                      className={`w-10 h-6 rounded-full flex items-center transition ${customDone[m.id] ? 'bg-neon-emerald/30' : 'bg-ink-600'}`}
                    >
                      <div className={`w-4 h-4 rounded-full transition-transform ${customDone[m.id] ? 'translate-x-5 bg-neon-emerald' : 'translate-x-1 bg-slate-400'}`} />
                    </button>
                  </div>
                ) : (
                  <Field
                    key={m.id}
                    label={`${m.name} (${m.unit})`}
                    value={customValues[m.id] || ''}
                    onChange={(v) => setCustomValues((prev) => ({ ...prev, [m.id]: v }))}
                    type="number"
                    step={m.type === 'scale' ? '1' : '0.1'}
                    placeholder={m.type === 'scale' ? '1-10' : '0'}
                  />
                ),
              )}
            </div>
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <button type="button" onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button type="submit" className="btn-primary flex-1">{isEditing ? 'Update Entry' : 'Save Entry'}</button>
        </div>
      </form>
    </Modal>
  );
}

function Field({ label, value, onChange, type, step, placeholder }: { label: string; value: string; onChange: (v: string) => void; type: string; step?: string; placeholder?: string }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-slate-400 mb-1.5">{label}</label>
      <input
        type={type}
        step={step}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="input-field"
      />
    </div>
  );
}

interface LogWorkoutModalProps {
  open: boolean;
  onClose: () => void;
}

export function LogWorkoutModal({ open, onClose }: LogWorkoutModalProps) {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [type, setType] = useState('');
  const [duration, setDuration] = useState('');
  const [intensity, setIntensity] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [calories, setCalories] = useState('');
  const [date, setDate] = useState(todayStr());

  useEffect(() => {
    if (open) {
      setType('');
      setDuration('');
      setIntensity('Medium');
      setCalories('');
      setDate(todayStr());
    }
  }, [open]);

  if (!user) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!type || !duration) {
      showToast('Please fill in workout type and duration', 'error');
      return;
    }
    const workout: Omit<WorkoutEntry, 'id'> = {
      date,
      type,
      duration: Number(duration),
      intensity,
      calories: Number(calories) || Math.round(Number(duration) * 7),
    };
    updateUser((u) => {
      addWorkout(u, workout);
      const existing = u.dailyLogs[date] || { date };
      u.dailyLogs[date] = { ...existing, calories: (existing.calories || 0) + workout.calories };
      if (!isGuest(u)) void syncUpsertDailyLog(u, u.dailyLogs[date]);
      return u;
    });
    showToast(`Workout logged: ${type} for ${duration} min`);
    onClose();
  };

  const WORKOUT_TYPES = ['Running', 'Cycling', 'Swimming', 'Weight Training', 'Yoga', 'HIIT', 'Walking', 'Pilates', 'Boxing', 'Other'];

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Log Workout"
      subtitle="Track your exercise sessions"
      icon={<Dumbbell size={20} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Date</label>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input-field" max={todayStr()} />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Workout Type</label>
          <div className="flex flex-wrap gap-2">
            {WORKOUT_TYPES.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setType(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  type === t ? 'bg-neon-purple/10 text-neon-purple border border-neon-purple/30' : 'bg-ink-800 text-slate-400 border border-ink-600 hover:text-slate-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Duration (min)" value={duration} onChange={setDuration} type="number" placeholder="45" />
          <Field label="Calories Burned" value={calories} onChange={setCalories} type="number" placeholder="Auto" />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Intensity</label>
          <div className="flex gap-2">
            {(['Low', 'Medium', 'High'] as const).map((lvl) => (
              <button
                key={lvl}
                type="button"
                onClick={() => setIntensity(lvl)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${
                  intensity === lvl
                    ? lvl === 'Low' ? 'bg-cyan-500/10 text-neon-cyan border border-cyan-500/30'
                      : lvl === 'Medium' ? 'bg-amber-500/10 text-neon-amber border border-amber-500/30'
                      : 'bg-red-500/10 text-red-400 border border-red-500/30'
                    : 'bg-ink-800 text-slate-400 border border-ink-600'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>
        <div className="flex gap-2 pt-2">
          <button type="button" onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button type="submit" className="btn-primary flex-1">Log Workout</button>
        </div>
      </form>
    </Modal>
  );
}

interface AddMetricModalProps {
  open: boolean;
  onClose: () => void;
}

const METRIC_COLORS = ['#10b981', '#06b6d4', '#a855f7', '#ec4899', '#f59e0b', '#3b82f6', '#8b5cf6'];

export function AddMetricModal({ open, onClose }: AddMetricModalProps) {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [name, setName] = useState('');
  const [unit, setUnit] = useState('');
  const [target, setTarget] = useState('');
  const [type, setType] = useState<MetricType>('numeric');
  const [color, setColor] = useState(METRIC_COLORS[0]);
  const [categoryId, setCategoryId] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName('');
      setUnit('');
      setTarget('');
      setType('numeric');
      setColor(METRIC_COLORS[Math.floor(Math.random() * METRIC_COLORS.length)]);
      setCategoryId(null);
    }
  }, [open]);

  if (!user) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !unit || !target) {
      showToast('Please fill in all fields', 'error');
      return;
    }
    updateUser((u) => addCustomMetric(u, { name, unit, target: Number(target), type, color, categoryId }));
    showToast(`Created "${name}" metric`);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add Custom Metric"
      subtitle="Create a new trackable health metric"
      icon={<Activity size={20} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Metric Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Protein Intake, Meditation"
            className="input-field"
            required
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">Unit</label>
            <input
              type="text"
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              placeholder="e.g., g, bpm, done"
              className="input-field"
              required
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">Daily Target</label>
            <input
              type="number"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              placeholder="e.g., 120"
              className="input-field"
              required
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Metric Type</label>
          <div className="flex flex-wrap gap-2">
            {([
              { id: 'numeric', label: 'Numeric' },
              { id: 'scale', label: 'Scale 1-10' },
              { id: 'duration', label: 'Duration' },
              { id: 'boolean', label: 'Done / Not Done' },
            ] as const).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setType(t.id)}
                className={`px-3 py-2 rounded-lg text-xs font-medium transition ${
                  type === t.id ? 'bg-neon-emerald/10 text-neon-emerald border border-neon-emerald/30' : 'bg-ink-800 text-slate-400 border border-ink-600'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Color</label>
          <div className="flex gap-2">
            {METRIC_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={`w-8 h-8 rounded-full transition ${color === c ? 'ring-2 ring-offset-2 ring-offset-ink-850' : ''}`}
                style={{ backgroundColor: c, boxShadow: color === c ? `0 0 0 2px ${c}` : 'none' }}
              />
            ))}
          </div>
        </div>
        {user.categories && user.categories.length > 0 && (
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">Category</label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setCategoryId(null)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  categoryId === null ? 'bg-slate-500/10 text-slate-300 border border-slate-500/30' : 'bg-ink-800 text-slate-400 border border-ink-600'
                }`}
              >
                Uncategorized
              </button>
              {user.categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategoryId(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    categoryId === cat.id ? 'border' : 'bg-ink-800 text-slate-400 border border-ink-600'
                  }`}
                  style={categoryId === cat.id ? { backgroundColor: `${cat.color}20`, color: cat.color, borderColor: `${cat.color}60` } : {}}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="flex gap-2 pt-2">
          <button type="button" onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button type="submit" className="btn-primary flex-1 flex items-center justify-center gap-2">
            <Plus size={16} /> Create Metric
          </button>
        </div>
      </form>
    </Modal>
  );
}

interface EditMetricModalProps {
  open: boolean;
  onClose: () => void;
  metric: CustomMetric | null;
}

export function EditMetricModal({ open, onClose, metric }: EditMetricModalProps) {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const [name, setName] = useState('');
  const [unit, setUnit] = useState('');
  const [target, setTarget] = useState('');
  const [type, setType] = useState<MetricType>('numeric');
  const [color, setColor] = useState(METRIC_COLORS[0]);
  const [categoryId, setCategoryId] = useState<string | null>(null);

  useEffect(() => {
    if (open && metric) {
      setName(metric.name);
      setUnit(metric.unit);
      setTarget(metric.target.toString());
      setType(metric.type);
      setColor(metric.color);
      setCategoryId(metric.categoryId);
    }
  }, [open, metric]);

  if (!user || !metric) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !unit || !target) {
      showToast('Please fill in all fields', 'error');
      return;
    }
    updateUser((u) => updateCustomMetric(u, metric.id, { name, unit, target: Number(target), type, color, categoryId }));
    showToast(`Updated "${name}" metric`);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Edit Metric"
      subtitle="Update metric details"
      icon={<Pencil size={20} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Metric Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Protein Intake, Meditation"
            className="input-field"
            required
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">Unit</label>
            <input
              type="text"
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              placeholder="e.g., g, bpm, done"
              className="input-field"
              required
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">Daily Target</label>
            <input
              type="number"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              placeholder="e.g., 120"
              className="input-field"
              required
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Metric Type</label>
          <div className="flex flex-wrap gap-2">
            {([
              { id: 'numeric', label: 'Numeric' },
              { id: 'scale', label: 'Scale 1-10' },
              { id: 'duration', label: 'Duration' },
              { id: 'boolean', label: 'Done / Not Done' },
            ] as const).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setType(t.id)}
                className={`px-3 py-2 rounded-lg text-xs font-medium transition ${
                  type === t.id ? 'bg-neon-emerald/10 text-neon-emerald border border-neon-emerald/30' : 'bg-ink-800 text-slate-400 border border-ink-600'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">Color</label>
          <div className="flex gap-2">
            {METRIC_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={`w-8 h-8 rounded-full transition ${color === c ? 'ring-2 ring-offset-2 ring-offset-ink-850' : ''}`}
                style={{ backgroundColor: c, boxShadow: color === c ? `0 0 0 2px ${c}` : 'none' }}
              />
            ))}
          </div>
        </div>
        {user.categories && user.categories.length > 0 && (
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">Category</label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setCategoryId(null)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  categoryId === null ? 'bg-slate-500/10 text-slate-300 border border-slate-500/30' : 'bg-ink-800 text-slate-400 border border-ink-600'
                }`}
              >
                Uncategorized
              </button>
              {user.categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategoryId(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    categoryId === cat.id ? 'border' : 'bg-ink-800 text-slate-400 border border-ink-600'
                  }`}
                  style={categoryId === cat.id ? { backgroundColor: `${cat.color}20`, color: cat.color, borderColor: `${cat.color}60` } : {}}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="flex gap-2 pt-2">
          <button type="button" onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button type="submit" className="btn-primary flex-1 flex items-center justify-center gap-2">
            <Pencil size={16} /> Save Changes
          </button>
        </div>
      </form>
    </Modal>
  );
}
