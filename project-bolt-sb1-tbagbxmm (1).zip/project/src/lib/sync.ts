import { supabase } from '@/lib/supabase';
import type { UserProfile, DailyLog, WorkoutEntry, CustomMetric, CustomMetricLog, FastingSession, Habit, MetricCategory } from '@/types';

function getUserId(user: UserProfile): string {
  return user.id;
}

export async function syncUpsertDailyLog(user: UserProfile, log: Partial<DailyLog> & { date: string }): Promise<void> {
  if (user.passwordHash === '' && !user.email) return; // guest
  const userId = getUserId(user);
  const { error } = await supabase.from('daily_logs').upsert({
    user_id: userId,
    date: log.date,
    weight: log.weight ?? null,
    sleep_hours: log.sleepHours ?? null,
    sleep_quality: log.sleepQuality ?? null,
    water: log.water ?? null,
    calories: log.calories ?? null,
  }, { onConflict: 'user_id,date' });
  if (error) console.error('syncUpsertDailyLog error:', error.message);
}

export async function syncDeleteDailyLog(user: UserProfile, date: string): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const userId = getUserId(user);
  const { error } = await supabase.from('daily_logs').delete().eq('user_id', userId).eq('date', date);
  if (error) console.error('syncDeleteDailyLog error:', error.message);
}

export async function syncInsertWorkout(user: UserProfile, workout: WorkoutEntry): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('workouts').insert({
    user_id: getUserId(user),
    date: workout.date,
    type: workout.type,
    duration: workout.duration,
    intensity: workout.intensity,
    calories: workout.calories,
  });
  if (error) console.error('syncInsertWorkout error:', error.message);
}

export async function syncUpdateWorkout(user: UserProfile, workout: WorkoutEntry): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('workouts').update({
    date: workout.date,
    type: workout.type,
    duration: workout.duration,
    intensity: workout.intensity,
    calories: workout.calories,
  }).eq('id', workout.id);
  if (error) console.error('syncUpdateWorkout error:', error.message);
}

export async function syncDeleteWorkout(user: UserProfile, workoutId: string): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('workouts').delete().eq('id', workoutId);
  if (error) console.error('syncDeleteWorkout error:', error.message);
}

export async function syncInsertMetric(user: UserProfile, metric: CustomMetric): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('custom_metrics').insert({
    id: metric.id,
    user_id: getUserId(user),
    name: metric.name,
    unit: metric.unit,
    target: metric.target,
    type: metric.type,
    color: metric.color,
  });
  if (error) console.error('syncInsertMetric error:', error.message);
}

export async function syncUpdateMetric(user: UserProfile, metric: CustomMetric): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('custom_metrics').update({
    name: metric.name,
    unit: metric.unit,
    target: metric.target,
    type: metric.type,
    color: metric.color,
  }).eq('id', metric.id);
  if (error) console.error('syncUpdateMetric error:', error.message);
}

export async function syncDeleteMetric(user: UserProfile, metricId: string): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('custom_metrics').delete().eq('id', metricId);
  if (error) console.error('syncDeleteMetric error:', error.message);
}

export async function syncUpsertMetricLog(user: UserProfile, metricId: string, log: CustomMetricLog): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('custom_metric_logs').upsert({
    user_id: getUserId(user),
    metric_id: metricId,
    date: log.date,
    value: log.value,
    done: log.done ?? false,
  }, { onConflict: 'user_id,metric_id,date' });
  if (error) console.error('syncUpsertMetricLog error:', error.message);
}

export async function syncDeleteMetricLog(user: UserProfile, metricId: string, date: string): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('custom_metric_logs').delete()
    .eq('user_id', getUserId(user)).eq('metric_id', metricId).eq('date', date);
  if (error) console.error('syncDeleteMetricLog error:', error.message);
}

export async function syncInsertFasting(user: UserProfile, session: FastingSession): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('fasting_sessions').insert({
    id: session.id,
    user_id: getUserId(user),
    started_at: session.startedAt,
    ended_at: session.endedAt,
    expected_end: session.expectedEnd,
    target_hours: session.targetHours,
    label: session.label,
  });
  if (error) console.error('syncInsertFasting error:', error.message);
}

export async function syncUpdateFasting(user: UserProfile, session: FastingSession): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('fasting_sessions').update({
    ended_at: session.endedAt,
  }).eq('id', session.id);
  if (error) console.error('syncUpdateFasting error:', error.message);
}

export async function syncInsertHabit(user: UserProfile, habit: Habit): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('habits').insert({
    id: habit.id,
    user_id: getUserId(user),
    name: habit.name,
    icon: habit.icon,
    color: habit.color,
  });
  if (error) console.error('syncInsertHabit error:', error.message);
}

export async function syncDeleteHabit(user: UserProfile, habitId: string): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('habits').delete().eq('id', habitId);
  if (error) console.error('syncDeleteHabit error:', error.message);
}

export async function syncUpsertHabitLog(user: UserProfile, habitId: string, date: string, done: boolean): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('habit_logs').upsert({
    user_id: getUserId(user),
    habit_id: habitId,
    date,
    done,
  }, { onConflict: 'user_id,habit_id,date' });
  if (error) console.error('syncUpsertHabitLog error:', error.message);
}

export async function syncUpdateProfile(user: UserProfile): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('profiles').update({
    name: user.name,
    avatar_color: user.avatarColor,
    height: user.height,
    target_calories: user.dailyTargets.calories,
    target_water: user.dailyTargets.water,
    target_sleep: user.dailyTargets.sleep,
    target_weight: user.dailyTargets.weight,
    layout_mode: user.dashboardPrefs?.layout || 'grid',
    card_order: user.dashboardPrefs?.cardOrder || [],
    hidden_cards: user.dashboardPrefs?.hiddenCards || [],
  }).eq('user_id', getUserId(user));
  if (error) console.error('syncUpdateProfile error:', error.message);
}

// === Categories ===

export async function syncInsertCategory(user: UserProfile, category: MetricCategory): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('metric_categories').insert({
    id: category.id,
    user_id: getUserId(user),
    name: category.name,
    color: category.color,
  });
  if (error) console.error('syncInsertCategory error:', error.message);
}

export async function syncUpdateCategory(user: UserProfile, category: MetricCategory): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('metric_categories').update({
    name: category.name,
    color: category.color,
  }).eq('id', category.id);
  if (error) console.error('syncUpdateCategory error:', error.message);
}

export async function syncDeleteCategory(user: UserProfile, categoryId: string): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('metric_categories').delete().eq('id', categoryId);
  if (error) console.error('syncDeleteCategory error:', error.message);
}

// === Fasting full update (for target/start time changes) ===

export async function syncUpdateFastingFull(user: UserProfile, session: FastingSession): Promise<void> {
  if (user.passwordHash === '' && !user.email) return;
  const { error } = await supabase.from('fasting_sessions').update({
    started_at: session.startedAt,
    ended_at: session.endedAt,
    expected_end: session.expectedEnd,
    target_hours: session.targetHours,
    label: session.label,
  }).eq('id', session.id);
  if (error) console.error('syncUpdateFastingFull error:', error.message);
}

export function isGuest(user: UserProfile): boolean {
  return user.passwordHash === '' && !user.email;
}
