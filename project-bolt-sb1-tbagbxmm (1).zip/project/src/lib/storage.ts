import type { UserProfile, AuthSession } from '@/types';
import { createDefaultAccounts, createGuestProfile } from './mockData';

const USERS_KEY = 'fitdash_users';
const SESSION_KEY = 'fitdash_session';
const GUEST_KEY = 'fitdash_guest';

export const storage = {
  getUsers(): UserProfile[] {
    try {
      const raw = localStorage.getItem(USERS_KEY);
      if (!raw) {
        const defaults = createDefaultAccounts();
        localStorage.setItem(USERS_KEY, JSON.stringify(defaults));
        return defaults;
      }
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  saveUsers(users: UserProfile[]): void {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  getUser(id: string): UserProfile | undefined {
    return this.getUsers().find((u) => u.id === id);
  }

  ,

  updateUser(user: UserProfile): void {
    const users = this.getUsers();
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx >= 0) {
      users[idx] = user;
    } else {
      users.push(user);
    }
    this.saveUsers(users);
  },

  getSession(): AuthSession {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return { userId: null, isGuest: false };
      return JSON.parse(raw);
    } catch {
      return { userId: null, isGuest: false };
    }
  },

  setSession(session: AuthSession): void {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  },

  clearSession(): void {
    localStorage.removeItem(SESSION_KEY);
  },

  getGuest(): UserProfile | null {
    try {
      const raw = localStorage.getItem(GUEST_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },

  saveGuest(guest: UserProfile): void {
    localStorage.setItem(GUEST_KEY, JSON.stringify(guest));
  },

  getOrCreateGuest(): UserProfile {
    const existing = this.getGuest();
    if (existing) return existing;
    const guest = createGuestProfile();
    this.saveGuest(guest);
    return guest;
  },

  clearGuest(): void {
    localStorage.removeItem(GUEST_KEY);
  },
};
