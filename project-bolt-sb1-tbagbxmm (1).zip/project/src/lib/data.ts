import type { UserProfile, DailyLog, WorkoutEntry, CustomMetric, CustomMetricLog, FastingSession, FastingStage, Habit, MetricCategory, DashboardLayout } from '@/types';
import {
  syncUpsertDailyLog, syncDeleteDailyLog, syncInsertWorkout, syncUpdateWorkout, syncDeleteWorkout,
  syncInsertMetric, syncUpdateMetric, syncDeleteMetric, syncUpsertMetricLog, syncDeleteMetricLog,
  syncInsertFasting, syncUpdateFasting, syncInsertHabit, syncDeleteHabit, syncUpsertHabitLog,
  syncUpdateProfile, isGuest,
  syncInsertCategory, syncUpdateCategory, syncDeleteCategory, syncUpdateFastingFull,
} from '@/lib/sync';

export function todayStr(): string {
  return new Date().toISOString().split('T')[0];
}

export function getLatestLog(user: UserProfile): DailyLog | null {
  const dates = Object.keys(user.dailyLogs).sort().reverse();
  return dates.length ? user.dailyLogs[dates[0]] : null;
}

export function getLogForDate(user: UserProfile, date: string): DailyLog | undefined {
  return user.dailyLogs[date];
}

export function upsertDailyLog(user: UserProfile, log: Partial<DailyLog> & { date: string }): UserProfile {
  const existing = user.dailyLogs[log.date] || { date: log.date };
  user.dailyLogs[log.date] = { ...existing, ...log };
  if (!isGuest(user)) void syncUpsertDailyLog(user, log);
  return user;
}

export function addWorkout(user: UserProfile, workout: Omit<WorkoutEntry, 'id'>): UserProfile {
  const w: WorkoutEntry = { ...workout, id: `wk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}` };
  user.workouts.push(w);
  if (!isGuest(user)) void syncInsertWorkout(user, w);
  return user;
}

export function updateWorkout(user: UserProfile, workout: WorkoutEntry): UserProfile {
  const idx = user.workouts.findIndex((w) => w.id === workout.id);
  if (idx >= 0) {
    user.workouts[idx] = workout;
    if (!isGuest(user)) void syncUpdateWorkout(user, workout);
  }
  return user;
}

export function removeWorkout(user: UserProfile, workoutId: string): UserProfile {
  user.workouts = user.workouts.filter((w) => w.id !== workoutId);
  if (!isGuest(user)) void syncDeleteWorkout(user, workoutId);
  return user;
}

export function addCustomMetric(user: UserProfile, metric: Omit<CustomMetric, 'id' | 'createdAt'>): UserProfile {
  const id = `cm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const fullMetric: CustomMetric = { ...metric, id, createdAt: Date.now() };
  user.customMetrics.push(fullMetric);
  user.customMetricLogs[id] = [];
  if (!isGuest(user)) void syncInsertMetric(user, fullMetric);
  return user;
}

export function removeCustomMetric(user: UserProfile, metricId: string): UserProfile {
  user.customMetrics = user.customMetrics.filter((m) => m.id !== metricId);
  delete user.customMetricLogs[metricId];
  if (!isGuest(user)) void syncDeleteMetric(user, metricId);
  return user;
}

export function updateCustomMetric(user: UserProfile, metricId: string, updates: Partial<Omit<CustomMetric, 'id' | 'createdAt'>>): UserProfile {
  const metric = user.customMetrics.find((m) => m.id === metricId);
  if (metric) {
    Object.assign(metric, updates);
    if (!isGuest(user)) void syncUpdateMetric(user, metric);
  }
  return user;
}

// === Habits ===

export function addHabit(user: UserProfile, habit: Omit<Habit, 'id' | 'createdAt' | 'logs'>): UserProfile {
  const id = `hb_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const fullHabit: Habit = { ...habit, id, createdAt: Date.now(), logs: {} };
  user.habits.push(fullHabit);
  if (!isGuest(user)) void syncInsertHabit(user, fullHabit);
  return user;
}

export function removeHabit(user: UserProfile, habitId: string): UserProfile {
  user.habits = user.habits.filter((h) => h.id !== habitId);
  if (!isGuest(user)) void syncDeleteHabit(user, habitId);
  return user;
}

export function toggleHabit(user: UserProfile, habitId: string, date: string): UserProfile {
  const habit = user.habits.find((h) => h.id === habitId);
  if (habit) {
    habit.logs[date] = !habit.logs[date];
    if (!isGuest(user)) void syncUpsertHabitLog(user, habitId, date, habit.logs[date]);
  }
  return user;
}

export function calcHabitStreak(habit: Habit): number {
  const today = todayStr();
  let streak = 0;
  let checkDate = today;
  // If today not done yet, start from yesterday
  if (!habit.logs[today]) {
    const d = new Date(today);
    d.setDate(d.getDate() - 1);
    checkDate = d.toISOString().split('T')[0];
  }
  while (habit.logs[checkDate]) {
    streak++;
    const d = new Date(checkDate);
    d.setDate(d.getDate() - 1);
    checkDate = d.toISOString().split('T')[0];
  }
  return streak;
}

export function getHabitCompletionRate(habit: Habit, days: number): number {
  let done = 0;
  for (let i = 0; i < days; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    if (habit.logs[dateStr]) done++;
  }
  return Math.round((done / days) * 100);
}

export function logCustomMetric(user: UserProfile, metricId: string, value: number, done?: boolean): UserProfile {
  const date = todayStr();
  const logs = user.customMetricLogs[metricId] || [];
  const idx = logs.findIndex((l) => l.date === date);
  let logEntry: CustomMetricLog;
  if (idx >= 0) {
    logs[idx].value = value;
    if (done !== undefined) logs[idx].done = done;
    logEntry = logs[idx];
  } else {
    logEntry = { date, value, done };
    logs.push(logEntry);
  }
  user.customMetricLogs[metricId] = logs;
  if (!isGuest(user)) void syncUpsertMetricLog(user, metricId, logEntry);
  return user;
}

export function getMetricLogs(user: UserProfile, metricId: string): CustomMetricLog[] {
  return (user.customMetricLogs[metricId] || []).slice().sort((a, b) => a.date.localeCompare(b.date));
}

export function calcStreak(logs: CustomMetricLog[], metricType: string): number {
  if (!logs.length) return 0;
  const sorted = logs.slice().sort((a, b) => b.date.localeCompare(a.date));
  let streak = 0;
  const today = todayStr();

  // For boolean metrics, count consecutive days done=true
  if (metricType === 'boolean') {
    let checkDate = today;
    for (const log of sorted) {
      if (log.date === checkDate) {
        if (log.done) {
          streak++;
          const d = new Date(checkDate);
          d.setDate(d.getDate() - 1);
          checkDate = d.toISOString().split('T')[0];
        } else {
          // If today not done yet, don't break streak - skip today
          if (checkDate === today) {
            const d = new Date(checkDate);
            d.setDate(d.getDate() - 1);
            checkDate = d.toISOString().split('T')[0];
            continue;
          }
          break;
        }
      } else if (log.date < checkDate) {
        // Gap found
        if (checkDate === today && !sorted.some((l) => l.date === today)) {
          // No log today, start from yesterday
          const d = new Date(checkDate);
          d.setDate(d.getDate() - 1);
          checkDate = d.toISOString().split('T')[0];
          continue;
        }
        break;
      }
    }
  } else {
    // For numeric metrics, count consecutive days with value >= target
    let checkDate = today;
    for (const log of sorted) {
      if (log.date === checkDate) {
        streak++;
        const d = new Date(checkDate);
        d.setDate(d.getDate() - 1);
        checkDate = d.toISOString().split('T')[0];
      } else if (log.date < checkDate) {
        if (checkDate === today) {
          const d = new Date(checkDate);
          d.setDate(d.getDate() - 1);
          checkDate = d.toISOString().split('T')[0];
          continue;
        }
        break;
      }
    }
  }
  return streak;
}

export function calcBMI(weightKg: number, heightCm: number): number {
  if (!heightCm || !weightKg) return 0;
  return Math.round((weightKg / Math.pow(heightCm / 100, 2)) * 10) / 10;
}

export function bmiStatus(bmi: number): { label: string; color: string; bg: string } {
  if (bmi === 0) return { label: 'No data', color: 'text-slate-400', bg: 'bg-slate-500/10' };
  if (bmi < 18.5) return { label: 'Underweight', color: 'text-neon-cyan', bg: 'bg-cyan-500/10' };
  if (bmi < 25) return { label: 'Normal', color: 'text-neon-emerald', bg: 'bg-emerald-500/10' };
  if (bmi < 30) return { label: 'Overweight', color: 'text-neon-amber', bg: 'bg-amber-500/10' };
  return { label: 'Obese', color: 'text-red-400', bg: 'bg-red-500/10' };
}

export function getRecentLogs(user: UserProfile, days: number): DailyLog[] {
  const allDates = Object.keys(user.dailyLogs).sort();
  return allDates.slice(-days).map((d) => user.dailyLogs[d]);
}

export function getRecentWorkouts(user: UserProfile, days: number): WorkoutEntry[] {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  const cutoffStr = cutoff.toISOString().split('T')[0];
  return user.workouts.filter((w) => w.date >= cutoffStr);
}

// === Fasting ===

export const FASTING_STAGES: { stage: FastingStage; hours: number; label: string; desc: string; color: string }[] = [
  { stage: 'fed', hours: 0, label: 'Fed', desc: 'Insulin high, body using food for energy', color: '#f59e0b' },
  { stage: 'early', hours: 4, label: 'Early Fasting', desc: 'Glycogen stores being depleted', color: '#06b6d4' },
  { stage: 'fatBurning', hours: 12, label: 'Fat Burning', desc: 'Body shifts to burning fat for fuel', color: '#10b981' },
  { stage: 'ketosis', hours: 18, label: 'Ketosis', desc: 'Liver producing ketones from fat', color: '#a855f7' },
  { stage: 'autophagy', hours: 24, label: 'Autophagy', desc: 'Cellular repair and cleanup begins', color: '#ec4899' },
];

export function getFastingStage(elapsedHours: number): typeof FASTING_STAGES[0] {
  let current = FASTING_STAGES[0];
  for (const s of FASTING_STAGES) {
    if (elapsedHours >= s.hours) current = s;
  }
  return current;
}

export function getNextStage(elapsedHours: number): typeof FASTING_STAGES[0] | null {
  for (const s of FASTING_STAGES) {
    if (s.hours > elapsedHours) return s;
  }
  return null;
}

export function startFastingSession(user: UserProfile, targetHours: number, label: string): UserProfile {
  const now = Date.now();
  const session: FastingSession = {
    id: `fast_${now}_${Math.random().toString(36).slice(2, 6)}`,
    startedAt: now,
    endedAt: null,
    expectedEnd: now + targetHours * 3600 * 1000,
    targetHours,
    label,
  };
  user.fastingSessions = [session, ...(user.fastingSessions || [])];
  if (!isGuest(user)) void syncInsertFasting(user, session);
  return user;
}

export function endFastingSession(user: UserProfile, sessionId: string): UserProfile {
  const session = (user.fastingSessions || []).find((s) => s.id === sessionId);
  if (session && session.endedAt === null) {
    session.endedAt = Date.now();
    if (!isGuest(user)) void syncUpdateFasting(user, session);
  }
  return user;
}

export function updateFastingTarget(user: UserProfile, sessionId: string, targetHours: number, label: string): UserProfile {
  const session = (user.fastingSessions || []).find((s) => s.id === sessionId);
  if (session && session.endedAt === null) {
    session.targetHours = targetHours;
    session.label = label;
    session.expectedEnd = session.startedAt + targetHours * 3600 * 1000;
    if (!isGuest(user)) void syncUpdateFastingFull(user, session);
  }
  return user;
}

export function updateFastingStartTime(user: UserProfile, sessionId: string, startedAt: number): UserProfile {
  const session = (user.fastingSessions || []).find((s) => s.id === sessionId);
  if (session && session.endedAt === null) {
    session.startedAt = startedAt;
    session.expectedEnd = startedAt + session.targetHours * 3600 * 1000;
    if (!isGuest(user)) void syncUpdateFastingFull(user, session);
  }
  return user;
}

export function getActiveFastingSession(user: UserProfile): FastingSession | null {
  return (user.fastingSessions || []).find((s) => s.endedAt === null) || null;
}

export function formatDuration(ms: number): string {
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function exportJSON(user: UserProfile): void {
  const blob = new Blob([JSON.stringify(user, null, 2)], { type: 'application/json' });
  downloadBlob(blob, `${user.name.replace(/\s+/g, '_')}_health_data.json`);
}

export function exportCSV(user: UserProfile): void {
  const rows: string[] = ['date,metric,value,unit'];
  for (const [date, log] of Object.entries(user.dailyLogs)) {
    if (log.weight != null) rows.push(`${date},weight,${log.weight},kg`);
    if (log.sleepHours != null) rows.push(`${date},sleep_hours,${log.sleepHours},hrs`);
    if (log.sleepQuality != null) rows.push(`${date},sleep_quality,${log.sleepQuality},score`);
    if (log.water != null) rows.push(`${date},water,${log.water},glasses`);
    if (log.calories != null) rows.push(`${date},calories,${log.calories},kcal`);
  }
  for (const metric of user.customMetrics) {
    for (const entry of user.customMetricLogs[metric.id] || []) {
      rows.push(`${entry.date},${metric.name},${entry.value},${metric.unit}`);
    }
  }
  for (const w of user.workouts) {
    rows.push(`${w.date},workout_${w.type},${w.duration},mins`);
  }
  const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
  downloadBlob(blob, `${user.name.replace(/\s+/g, '_')}_health_data.csv`);
}

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// === Categories ===

export const DEFAULT_CATEGORIES: MetricCategory[] = [
  { id: 'cat_mobility', name: 'Mobility', color: '#06b6d4' },
  { id: 'cat_exercise', name: 'Exercise Related', color: '#10b981' },
  { id: 'cat_health', name: 'Overall Health', color: '#a855f7' },
];

export function ensureCategories(user: UserProfile): UserProfile {
  if (!user.categories || user.categories.length === 0) {
    user.categories = DEFAULT_CATEGORIES.map((c) => ({ ...c }));
  }
  return user;
}

export function addCategory(user: UserProfile, name: string, color: string): UserProfile {
  const id = `cat_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const category: MetricCategory = { id, name, color };
  user.categories = [...(user.categories || []), category];
  if (!isGuest(user)) void syncInsertCategory(user, category);
  return user;
}

export function updateCategory(user: UserProfile, categoryId: string, updates: { name?: string; color?: string }): UserProfile {
  const cat = (user.categories || []).find((c) => c.id === categoryId);
  if (cat) {
    if (updates.name !== undefined) cat.name = updates.name;
    if (updates.color !== undefined) cat.color = updates.color;
    if (!isGuest(user)) void syncUpdateCategory(user, cat);
  }
  return user;
}

export function deleteCategory(user: UserProfile, categoryId: string): UserProfile {
  user.categories = (user.categories || []).filter((c) => c.id !== categoryId);
  // Null out categoryId on metrics that used it
  for (const m of user.customMetrics) {
    if (m.categoryId === categoryId) m.categoryId = null;
  }
  if (!isGuest(user)) void syncDeleteCategory(user, categoryId);
  return user;
}

export function getCategoryName(user: UserProfile, categoryId: string | null): string {
  if (!categoryId) return 'Uncategorized';
  const cat = (user.categories || []).find((c) => c.id === categoryId);
  return cat ? cat.name : 'Uncategorized';
}

export function getCategoryColor(user: UserProfile, categoryId: string | null): string {
  if (!categoryId) return '#64748b';
  const cat = (user.categories || []).find((c) => c.id === categoryId);
  return cat ? cat.color : '#64748b';
}

// === Dashboard Layout Prefs ===

export function setDashboardLayout(user: UserProfile, layout: DashboardLayout): UserProfile {
  user.dashboardPrefs = { ...(user.dashboardPrefs || { layout: 'grid', cardOrder: [], hiddenCards: [] }), layout };
  if (!isGuest(user)) void syncUpdateProfile(user);
  return user;
}

export function toggleCardVisibility(user: UserProfile, cardId: string): UserProfile {
  const prefs = user.dashboardPrefs || { layout: 'grid' as DashboardLayout, cardOrder: [], hiddenCards: [] };
  if (prefs.hiddenCards.includes(cardId)) {
    prefs.hiddenCards = prefs.hiddenCards.filter((id) => id !== cardId);
  } else {
    prefs.hiddenCards = [...prefs.hiddenCards, cardId];
  }
  user.dashboardPrefs = prefs;
  if (!isGuest(user)) void syncUpdateProfile(user);
  return user;
}

export function reorderCards(user: UserProfile, newOrder: string[]): UserProfile {
  const prefs = user.dashboardPrefs || { layout: 'grid' as DashboardLayout, cardOrder: [], hiddenCards: [] };
  prefs.cardOrder = newOrder;
  user.dashboardPrefs = prefs;
  if (!isGuest(user)) void syncUpdateProfile(user);
  return user;
}

// === Single Metric Logging ===

export function logSingleMetric(user: UserProfile, metricId: string, value: number, done: boolean, date?: string): UserProfile {
  const logDate = date || todayStr();
  const logs = user.customMetricLogs[metricId] || [];
  const idx = logs.findIndex((l) => l.date === logDate);
  let logEntry: CustomMetricLog;
  if (idx >= 0) {
    logs[idx].value = value;
    if (done !== undefined) logs[idx].done = done;
    logEntry = logs[idx];
  } else {
    logEntry = { date: logDate, value, done };
    logs.push(logEntry);
  }
  user.customMetricLogs[metricId] = logs;
  if (!isGuest(user)) void syncUpsertMetricLog(user, metricId, logEntry);
  return user;
}

export function logSingleDailyMetric(user: UserProfile, field: 'weight' | 'sleepHours' | 'sleepQuality' | 'water' | 'calories', value: number, date?: string): UserProfile {
  const logDate = date || todayStr();
  const existing = user.dailyLogs[logDate] || { date: logDate };
  existing[field] = value;
  user.dailyLogs[logDate] = existing;
  if (!isGuest(user)) void syncUpsertDailyLog(user, existing);
  return user;
}
