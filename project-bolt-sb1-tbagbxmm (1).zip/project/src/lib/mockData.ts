import type { UserProfile, DailyLog, WorkoutEntry, CustomMetricLog, MetricCategory } from '@/types';
import { DEFAULT_CATEGORIES } from '@/lib/data';

const AVATAR_COLORS = [
  '#10b981', '#06b6d4', '#a855f7', '#ec4899', '#f59e0b', '#8b5cf6',
];

const WORKOUT_TYPES = ['Running', 'Cycling', 'Swimming', 'Weight Training', 'Yoga', 'HIIT'];
const INTENSITIES = ['Low', 'Medium', 'High'] as const;

function hash(str: string): string {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  }
  return String(h);
}

function dateStr(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().split('T')[0];
}

function rand(min: number, max: number): number {
  return Math.round((min + Math.random() * (max - min)) * 10) / 10;
}

function generateDailyLogs(): Record<string, DailyLog> {
  const logs: Record<string, DailyLog> = {};
  for (let i = 13; i >= 0; i--) {
    const date = dateStr(i);
    const weight = rand(70, 75) - i * 0.05;
    logs[date] = {
      date,
      weight: Math.round(weight * 10) / 10,
      sleepHours: rand(6, 9),
      sleepQuality: Math.round(rand(60, 95)),
      water: Math.round(rand(4, 10)),
      calories: Math.round(rand(200, 800)),
    };
  }
  return logs;
}

function generateWorkouts(): WorkoutEntry[] {
  const workouts: WorkoutEntry[] = [];
  for (let i = 0; i < 8; i++) {
    const daysAgo = Math.floor(Math.random() * 14);
    workouts.push({
      id: `wk_${i}_${Date.now()}`,
      date: dateStr(daysAgo),
      type: WORKOUT_TYPES[Math.floor(Math.random() * WORKOUT_TYPES.length)],
      duration: Math.round(rand(20, 90)),
      intensity: INTENSITIES[Math.floor(Math.random() * INTENSITIES.length)],
      calories: Math.round(rand(150, 600)),
    });
  }
  return workouts;
}

function generateBooleanLogs(days: number, doneChance: number): CustomMetricLog[] {
  const logs: CustomMetricLog[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const done = Math.random() < doneChance;
    logs.push({ date: dateStr(i), value: done ? 1 : 0, done });
  }
  return logs;
}

export function createProfile(
  email: string,
  name: string,
  password: string,
  height = 175,
): UserProfile {
  return {
    id: `user_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    email,
    name,
    passwordHash: hash(password),
    avatarColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
    height,
    dailyTargets: {
      calories: 600,
      water: 8,
      sleep: 8,
      weight: 72,
    },
    customMetrics: [],
    dailyLogs: generateDailyLogs(),
    workouts: generateWorkouts(),
    customMetricLogs: {},
    fastingSessions: [],
    habits: [],
    categories: DEFAULT_CATEGORIES.map((c) => ({ ...c })),
    dashboardPrefs: { layout: 'grid', cardOrder: [], hiddenCards: [] },
    createdAt: Date.now(),
  };
}

export function createGuestProfile(): UserProfile {
  const guest = createProfile('guest@preview.app', 'Guest User', 'guest', 178);
  guest.customMetrics = [
    {
      id: 'cm_protein',
      name: 'Protein Intake',
      unit: 'g',
      target: 120,
      type: 'numeric',
      color: '#06b6d4',
      categoryId: 'cat_health',
      createdAt: Date.now(),
    },
    {
      id: 'cm_rhr',
      name: 'Resting Heart Rate',
      unit: 'bpm',
      target: 65,
      type: 'numeric',
      color: '#ec4899',
      categoryId: 'cat_health',
      createdAt: Date.now(),
    },
    {
      id: 'cm_meditate',
      name: 'Meditation',
      unit: 'done',
      target: 1,
      type: 'boolean',
      color: '#10b981',
      categoryId: 'cat_mobility',
      createdAt: Date.now(),
    },
  ];
  for (const metric of guest.customMetrics) {
    if (metric.type === 'boolean') {
      guest.customMetricLogs[metric.id] = generateBooleanLogs(14, 0.7);
    } else {
      const logs: CustomMetricLog[] = [];
      for (let i = 13; i >= 0; i--) {
        const baseVal = metric.id === 'cm_protein' ? rand(80, 140) : rand(58, 72);
        logs.push({ date: dateStr(i), value: Math.round(baseVal) });
      }
      guest.customMetricLogs[metric.id] = logs;
    }
  }
  // Add a completed fasting session
  const yesterday = Date.now() - 20 * 3600 * 1000;
  guest.fastingSessions = [
    {
      id: 'fast_demo_1',
      startedAt: yesterday - 16 * 3600 * 1000,
      endedAt: yesterday,
      expectedEnd: yesterday,
      targetHours: 16,
      label: '16:8 Daily Fast',
    },
  ];
  // Add sample habits
  const habitLogs = (doneChance: number): Record<string, boolean> => {
    const logs: Record<string, boolean> = {};
    for (let i = 13; i >= 0; i--) {
      logs[dateStr(i)] = Math.random() < doneChance;
    }
    return logs;
  };
  guest.habits = [
    { id: 'hb_read', name: 'Read 30 min', icon: 'BookOpen', color: '#06b6d4', createdAt: Date.now(), logs: habitLogs(0.8) },
    { id: 'hb_walk', name: 'Morning Walk', icon: 'Footprints', color: '#10b981', createdAt: Date.now(), logs: habitLogs(0.6) },
    { id: 'hb_nosugar', name: 'No Sugar', icon: 'Ban', color: '#ec4899', createdAt: Date.now(), logs: habitLogs(0.5) },
  ];
  return guest;
}

export function createDefaultAccounts(): UserProfile[] {
  return [
    (() => {
      const p = createProfile('alex@fit.app', 'Alex Carter', 'demo123', 180);
      p.customMetrics = [
        {
          id: 'cm_steps',
          name: 'Step Count',
          unit: 'steps',
          target: 10000,
          type: 'numeric',
          color: '#a855f7',
          categoryId: 'cat_exercise',
          createdAt: Date.now(),
        },
        {
          id: 'cm_supplements',
          name: 'Took Supplements',
          unit: 'done',
          target: 1,
          type: 'boolean',
          color: '#10b981',
          categoryId: 'cat_health',
          createdAt: Date.now(),
        },
      ];
      p.customMetricLogs['cm_steps'] = Array.from({ length: 14 }, (_, i) => ({
        date: dateStr(13 - i),
        value: Math.round(rand(4000, 12000)),
      }));
      p.customMetricLogs['cm_supplements'] = generateBooleanLogs(14, 0.6);
      p.fastingSessions = [
        {
          id: 'fast_alex_1',
          startedAt: Date.now() - 2 * 24 * 3600 * 1000,
          endedAt: Date.now() - 2 * 24 * 3600 * 1000 + 18 * 3600 * 1000,
          expectedEnd: Date.now() - 2 * 24 * 3600 * 1000 + 18 * 3600 * 1000,
          targetHours: 18,
          label: '18hr Fast',
        },
      ];
      p.habits = [
        { id: 'hb_water', name: 'Drink Water', icon: 'Droplets', color: '#3b82f6', createdAt: Date.now(), logs: Object.fromEntries(Array.from({ length: 14 }, (_, i) => [dateStr(13 - i), Math.random() < 0.85])) },
      ];
      return p;
    })(),
    createProfile('sam@fit.app', 'Sam Rivera', 'demo123', 165),
  ];
}
