import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ToastProvider } from '@/context/ToastContext';
import { LoginScreen } from '@/components/LoginScreen';
import { Sidebar, MobileNav, TopBar } from '@/components/Layout';
import { OverviewCards } from '@/components/OverviewCards';
import { ChartsSection } from '@/components/Charts';
import { WorkoutsView } from '@/components/WorkoutsView';
import { FastingView } from '@/components/FastingView';
import { HabitsView } from '@/components/HabitsView';
import { LogHistoryView } from '@/components/LogHistoryView';
import { MetricDetailView } from '@/components/MetricDetailView';
import { BuiltInMetricDetail, type BuiltInMetricId } from '@/components/BuiltInMetricDetail';
import { LogEntryModal, LogWorkoutModal, AddMetricModal, EditMetricModal } from '@/components/Modals';
import { ToastContainer } from '@/components/ui/Toast';
import { removeCustomMetric } from '@/lib/data';
import { Plus, Dumbbell, Activity, Sparkles, Timer, CheckCircle2, Loader2, History, AlertCircle, RotateCw } from 'lucide-react';
import type { CustomMetric } from '@/types';

export type ViewType = 'dashboard' | 'workouts' | 'habits' | 'fasting' | 'history';

function Dashboard() {
  const { user, loading, authError, retry, logout, updateUser } = useAuth();
  const [view, setView] = useState<ViewType>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [logEntryOpen, setLogEntryOpen] = useState(false);
  const [logWorkoutOpen, setLogWorkoutOpen] = useState(false);
  const [addMetricOpen, setAddMetricOpen] = useState(false);
  const [detailMetricId, setDetailMetricId] = useState<string | null>(null);
  const [builtInMetricId, setBuiltInMetricId] = useState<BuiltInMetricId | null>(null);
  const [editMetric, setEditMetric] = useState<CustomMetric | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen bg-ink-950 flex items-center justify-center">
        <Loader2 size={32} className="animate-spin text-neon-emerald" />
      </div>
    );
  }

  if (authError && !user) {
    return (
      <div className="min-h-screen bg-ink-950 flex items-center justify-center p-6">
        <div className="glass-card p-8 max-w-md text-center">
          <AlertCircle size={40} className="mx-auto text-red-400 mb-4" />
          <h2 className="text-lg font-bold text-slate-100 mb-2">Database Error</h2>
          <p className="text-sm text-slate-400 mb-1">Failed to load your profile data.</p>
          <p className="text-xs text-slate-500 mb-5 font-mono break-all">{authError}</p>
          <div className="flex gap-2 justify-center">
            <button onClick={retry} className="btn-primary text-xs flex items-center gap-1.5">
              <RotateCw size={14} /> Retry
            </button>
            <button onClick={logout} className="btn-ghost text-xs">
              Back to Login
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!user) return <LoginScreen />;

  const handleDeleteMetric = (metric: CustomMetric) => {
    updateUser((u) => removeCustomMetric(u, metric.id));
    setDetailMetricId(null);
  };

  return (
    <div className="min-h-screen bg-ink-950">
      <Sidebar
        view={view}
        onViewChange={setView}
        onLogEntry={() => setLogEntryOpen(true)}
        onLogWorkout={() => setLogWorkoutOpen(true)}
        onAddMetric={() => setAddMetricOpen(true)}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed((c) => !c)}
      />
      <div className={`transition-all duration-300 ${sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <TopBar
          onLogEntry={() => setLogEntryOpen(true)}
          onLogWorkout={() => setLogWorkoutOpen(true)}
          onAddMetric={() => setAddMetricOpen(true)}
        />
        <main className="p-4 sm:p-6 pb-24 lg:pb-6">
          {view === 'dashboard' ? (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <h1 className="text-2xl font-extrabold text-slate-100">
                    Hello, {user.name.split(' ')[0]}
                  </h1>
                  <p className="text-sm text-slate-400 mt-0.5">Here's your health snapshot for today</p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setLogEntryOpen(true)} className="btn-primary text-xs flex items-center gap-1.5">
                    <Plus size={14} /> Log Entry
                  </button>
                  <button onClick={() => setAddMetricOpen(true)} className="btn-ghost text-xs flex items-center gap-1.5">
                    <Activity size={14} /> New Metric
                  </button>
                </div>
              </div>

              <OverviewCards onMetricClick={setBuiltInMetricId} />
              <ChartsSection onMetricClick={setDetailMetricId} />

              <div className="glass-card p-5 animate-slide-up">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-neon-emerald/10 flex items-center justify-center shrink-0">
                    <Sparkles size={20} className="text-neon-emerald" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-100">Quick Actions</h3>
                    <p className="text-sm text-slate-400 mt-0.5">Log your daily metrics, record workouts, or create custom health trackers.</p>
                    <div className="flex flex-wrap gap-2 mt-3">
                      <button onClick={() => setLogEntryOpen(true)} className="btn-ghost text-xs flex items-center gap-1.5">
                        <Plus size={14} /> Log Health Entry
                      </button>
                      <button onClick={() => setLogWorkoutOpen(true)} className="btn-ghost text-xs flex items-center gap-1.5">
                        <Dumbbell size={14} /> Log Workout
                      </button>
                      <button onClick={() => setAddMetricOpen(true)} className="btn-ghost text-xs flex items-center gap-1.5">
                        <Activity size={14} /> Add Custom Metric
                      </button>
                      <button onClick={() => setView('fasting')} className="btn-ghost text-xs flex items-center gap-1.5">
                        <Timer size={14} /> Start Fasting
                      </button>
                      <button onClick={() => setView('habits')} className="btn-ghost text-xs flex items-center gap-1.5">
                        <CheckCircle2 size={14} /> Track Habits
                      </button>
                      <button onClick={() => setView('history')} className="btn-ghost text-xs flex items-center gap-1.5">
                        <History size={14} /> View Log History
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : view === 'workouts' ? (
            <div className="animate-fade-in">
              <WorkoutsView onLogWorkout={() => setLogWorkoutOpen(true)} />
            </div>
          ) : view === 'habits' ? (
            <div className="animate-fade-in">
              <HabitsView />
            </div>
          ) : view === 'history' ? (
            <div className="animate-fade-in">
              <LogHistoryView />
            </div>
          ) : (
            <div className="animate-fade-in">
              <FastingView />
            </div>
          )}
        </main>
      </div>

      <MobileNav view={view} onViewChange={setView} onLogEntry={() => setLogEntryOpen(true)} />

      <LogEntryModal open={logEntryOpen} onClose={() => setLogEntryOpen(false)} />
      <LogWorkoutModal open={logWorkoutOpen} onClose={() => setLogWorkoutOpen(false)} />
      <AddMetricModal open={addMetricOpen} onClose={() => setAddMetricOpen(false)} />
      <EditMetricModal open={!!editMetric} onClose={() => setEditMetric(null)} metric={editMetric} />
      <MetricDetailView
        metricId={detailMetricId}
        onClose={() => setDetailMetricId(null)}
        onEdit={(m) => { setDetailMetricId(null); setEditMetric(m); }}
        onDelete={handleDeleteMetric}
      />
      <BuiltInMetricDetail metricId={builtInMetricId} onClose={() => setBuiltInMetricId(null)} />
      <ToastContainer />
    </div>
  );
}

function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <Dashboard />
      </AuthProvider>
    </ToastProvider>
  );
}

export default App;
